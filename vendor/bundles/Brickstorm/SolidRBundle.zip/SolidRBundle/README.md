SolidRBundle
============