<?php
namespace Brickstorm\WorldBundle\Controller\Admin;

use Sonata\AdminBundle\Controller\CRUDController as Controller;

class ContinentAdminController extends Controller
{

}