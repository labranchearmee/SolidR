<?php
namespace Brickstorm\WorldBundle\Controller\Admin;

use Sonata\AdminBundle\Controller\CRUDController as Controller;

class CountryAdminController extends Controller
{

}