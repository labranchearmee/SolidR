<?php

namespace Brickstorm\WorldBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BrickstormWorldBundle extends Bundle
{
}
