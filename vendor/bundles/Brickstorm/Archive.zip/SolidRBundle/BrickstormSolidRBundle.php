<?php

namespace Brickstorm\SolidRBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BrickstormSolidRBundle extends Bundle
{
}
