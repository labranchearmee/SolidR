<?php

namespace Brickstorm\AmndrcBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BrickstormAmndrcBundle extends Bundle
{
}
