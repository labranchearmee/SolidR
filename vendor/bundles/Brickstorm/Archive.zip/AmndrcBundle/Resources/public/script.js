
// carousels
$('.carousel').carousel({
  interval: 2000
})

//modal
$('#modal').on('show', function () {
  console.log(this);
  var quantity = $('select[name=quantity]').val;
  var rythm = $(this);
})