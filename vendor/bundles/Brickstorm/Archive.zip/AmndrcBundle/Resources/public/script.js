
// carousels
$('.carousel').carousel({
  interval: 2000
})