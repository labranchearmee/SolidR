<?php

namespace Brickstorm\FormBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BrickstormFormBundle extends Bundle
{
}
