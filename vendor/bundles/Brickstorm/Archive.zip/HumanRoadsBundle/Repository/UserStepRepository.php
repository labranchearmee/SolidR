<?php

namespace Brickstorm\HumanRoadsBundle\Repository;

use Doctrine\ORM\EntityRepository;

class UserStepRepository extends EntityRepository
{

    /**
    * return the node
    *
    */
    public function findNode($node_type, $node_id)
    {
        return $this->getEntityManager()
                    ->getRepository('MrStartBundle:'.$node_type)
                    ->findOneBy(array('id' => $node_id));
    }

}