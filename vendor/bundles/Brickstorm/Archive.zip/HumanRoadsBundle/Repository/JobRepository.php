<?php

namespace Brickstorm\HumanRoadsBundle\Repository;

use Doctrine\ORM\EntityRepository;

class JobRepository extends EntityRepository
{

}