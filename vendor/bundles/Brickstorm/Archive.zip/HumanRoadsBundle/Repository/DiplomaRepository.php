<?php

namespace Brickstorm\HumanRoadsBundle\Repository;

use Doctrine\ORM\EntityRepository;

class DiplomaRepository extends EntityRepository
{


}