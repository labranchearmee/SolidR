<?php

namespace Brickstorm\HumanRoadsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Brickstorm\HumanRoadsBundle\Entity\DiplomaType
 */
class DiplomaType
{
    protected $locale;
    
   
    /**
     * @var integer $id
     */
    private $id;

    /**
     * @var string $name
     */
    private $name;

    /**
     * @var date $created_at
     */
    private $created_at;

    /**
     * @var datetime $updated_at
     */
    private $updated_at;

    /**
     * @var Brickstorm\HumanRoadsBundle\Entity\DiplomaLevel
     */
    private $level;

    /**
     * @var Brickstorm\WorldBundle\Entity\Country
     */
    private $country;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set created_at
     *
     * @param date $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->created_at = $createdAt;
    }

    /**
     * Get created_at
     *
     * @return date 
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * Set updated_at
     *
     * @param datetime $updatedAt
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updated_at = $updatedAt;
    }

    /**
     * Get updated_at
     *
     * @return datetime 
     */
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }

    /**
     * Set level
     *
     * @param Brickstorm\HumanRoadsBundle\Entity\DiplomaLevel $level
     */
    public function setLevel(\Brickstorm\HumanRoadsBundle\Entity\DiplomaLevel $level)
    {
        $this->level = $level;
    }

    /**
     * Get level
     *
     * @return Brickstorm\HumanRoadsBundle\Entity\DiplomaLevel 
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * Set country
     *
     * @param Brickstorm\WorldBundle\Entity\Country $country
     */
    public function setCountry(\Brickstorm\WorldBundle\Entity\Country $country)
    {
        $this->country = $country;
    }

    /**
     * Get country
     *
     * @return Brickstorm\WorldBundle\Entity\Country 
     */
    public function getCountry()
    {
        return $this->country;
    }
}