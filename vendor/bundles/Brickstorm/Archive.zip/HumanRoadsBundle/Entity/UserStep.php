<?php

namespace Brickstorm\HumanRoadsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Brickstorm\HumanRoadsBundle\Entity\UserStep
 */
class UserStep
{
    protected $locale;
    
   
    /**
     * @var integer $id
     */
    private $id;

    /**
     * @var integer $node_id
     */
    private $node_id;

    /**
     * @var string $node_type
     */
    private $node_type;

    /**
     * @var date $start_at
     */
    private $start_at;

    /**
     * @var date $end_at
     */
    private $end_at;

    /**
     * @var text $comment
     */
    private $comment;

    /**
     * @var boolean $liked
     */
    private $liked;

    /**
     * @var boolean $current
     */
    private $current;

    /**
     * @var date $created_at
     */
    private $created_at;

    /**
     * @var datetime $updated_at
     */
    private $updated_at;

    /**
     * @var Application\Sonata\UserBundle\Entity\User
     */
    private $user;

    /**
     * @var Brickstorm\WorldBundle\Entity\Location
     */
    private $location;

    /**
     * @var Brickstorm\HumanRoadsBundle\Entity\UserStep
     */
    private $stepacquaintance;

    public function __construct()
    {
        $this->stepacquaintance = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set node_id
     *
     * @param integer $nodeId
     */
    public function setNodeId($nodeId)
    {
        $this->node_id = $nodeId;
    }

    /**
     * Get node_id
     *
     * @return integer 
     */
    public function getNodeId()
    {
        return $this->node_id;
    }

    /**
     * Set node_type
     *
     * @param string $nodeType
     */
    public function setNodeType($nodeType)
    {
        $this->node_type = $nodeType;
    }

    /**
     * Get node_type
     *
     * @return string 
     */
    public function getNodeType()
    {
        return $this->node_type;
    }

    /**
     * Set start_at
     *
     * @param date $startAt
     */
    public function setStartAt($startAt)
    {
        $this->start_at = $startAt;
    }

    /**
     * Get start_at
     *
     * @return date 
     */
    public function getStartAt()
    {
        return $this->start_at;
    }

    /**
     * Set end_at
     *
     * @param date $endAt
     */
    public function setEndAt($endAt)
    {
        $this->end_at = $endAt;
    }

    /**
     * Get end_at
     *
     * @return date 
     */
    public function getEndAt()
    {
        return $this->end_at;
    }

    /**
     * Set comment
     *
     * @param text $comment
     */
    public function setComment($comment)
    {
        $this->comment = $comment;
    }

    /**
     * Get comment
     *
     * @return text 
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * Set liked
     *
     * @param boolean $liked
     */
    public function setLiked($liked)
    {
        $this->liked = $liked;
    }

    /**
     * Get liked
     *
     * @return boolean 
     */
    public function getLiked()
    {
        return $this->liked;
    }

    /**
     * Set current
     *
     * @param boolean $current
     */
    public function setCurrent($current)
    {
        $this->current = $current;
    }

    /**
     * Get current
     *
     * @return boolean 
     */
    public function getCurrent()
    {
        return $this->current;
    }

    /**
     * Set created_at
     *
     * @param date $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->created_at = $createdAt;
    }

    /**
     * Get created_at
     *
     * @return date 
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * Set updated_at
     *
     * @param datetime $updatedAt
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updated_at = $updatedAt;
    }

    /**
     * Get updated_at
     *
     * @return datetime 
     */
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }

    /**
     * Set user
     *
     * @param Application\Sonata\UserBundle\Entity\User $user
     */
    public function setUser(\Application\Sonata\UserBundle\Entity\User $user)
    {
        $this->user = $user;
    }

    /**
     * Get user
     *
     * @return Application\Sonata\UserBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set location
     *
     * @param Brickstorm\WorldBundle\Entity\Location $location
     */
    public function setLocation(\Brickstorm\WorldBundle\Entity\Location $location)
    {
        $this->location = $location;
    }

    /**
     * Get location
     *
     * @return Brickstorm\WorldBundle\Entity\Location 
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Add stepacquaintance
     *
     * @param Brickstorm\HumanRoadsBundle\Entity\UserStep $stepacquaintance
     */
    public function addUserStep(\Brickstorm\HumanRoadsBundle\Entity\UserStep $stepacquaintance)
    {
        $this->stepacquaintance[] = $stepacquaintance;
    }

    /**
     * Get stepacquaintance
     *
     * @return Doctrine\Common\Collections\Collection 
     */
    public function getStepacquaintance()
    {
        return $this->stepacquaintance;
    }
}