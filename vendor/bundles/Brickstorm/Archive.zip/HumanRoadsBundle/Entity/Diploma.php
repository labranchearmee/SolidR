<?php

namespace Brickstorm\HumanRoadsBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Brickstorm\HumanRoadsBundle\Entity\Diploma
 */
class Diploma
{
    protected $locale;
    
   
    /**
     * @var integer $id
     */
    private $id;

    /**
     * @var string $name
     */
    private $name;

    /**
     * @var string $slug
     */
    private $slug;

    /**
     * @var text $twitterhash
     */
    private $twitterhash;

    /**
     * @var date $created_at
     */
    private $created_at;

    /**
     * @var datetime $updated_at
     */
    private $updated_at;

    /**
     * @var Brickstorm\HumanRoadsBundle\Entity\DiplomaType
     */
    private $type;

    /**
     * @var Brickstorm\HumanRoadsBundle\Entity\Area
     */
    private $areas;

    public function __construct()
    {
        $this->areas = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set slug
     *
     * @param string $slug
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;
    }

    /**
     * Get slug
     *
     * @return string 
     */
    public function getSlug()
    {
        return $this->slug;
    }

    /**
     * Set twitterhash
     *
     * @param text $twitterhash
     */
    public function setTwitterhash($twitterhash)
    {
        $this->twitterhash = $twitterhash;
    }

    /**
     * Get twitterhash
     *
     * @return text 
     */
    public function getTwitterhash()
    {
        return $this->twitterhash;
    }

    /**
     * Set created_at
     *
     * @param date $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->created_at = $createdAt;
    }

    /**
     * Get created_at
     *
     * @return date 
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * Set updated_at
     *
     * @param datetime $updatedAt
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updated_at = $updatedAt;
    }

    /**
     * Get updated_at
     *
     * @return datetime 
     */
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }

    /**
     * Set type
     *
     * @param Brickstorm\HumanRoadsBundle\Entity\DiplomaType $type
     */
    public function setType(\Brickstorm\HumanRoadsBundle\Entity\DiplomaType $type)
    {
        $this->type = $type;
    }

    /**
     * Get type
     *
     * @return Brickstorm\HumanRoadsBundle\Entity\DiplomaType 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Add areas
     *
     * @param Brickstorm\HumanRoadsBundle\Entity\Area $areas
     */
    public function addArea(\Brickstorm\HumanRoadsBundle\Entity\Area $areas)
    {
        $this->areas[] = $areas;
    }

    /**
     * Get areas
     *
     * @return Doctrine\Common\Collections\Collection 
     */
    public function getAreas()
    {
        return $this->areas;
    }
}