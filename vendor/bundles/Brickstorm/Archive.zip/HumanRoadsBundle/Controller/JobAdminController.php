<?php
namespace Brickstorm\HumanRoadsBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController as Controller;

class JobAdminController extends Controller
{

}