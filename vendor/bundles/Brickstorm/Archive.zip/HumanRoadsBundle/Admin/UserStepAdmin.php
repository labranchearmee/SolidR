<?php
namespace Brickstorm\HumanRoadsBundle\Admin;

use Sonata\AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;

use Knplabs\Bundle\MenuBundle\MenuItem;

use Brickstorm\HumanRoadsBundle\Entity\UserStep;

class UserStepAdmin extends Admin
{

    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
                ->addIdentifier('id')
                ->add('user')
                ->add('node_type')
                ->add('node_id')
                ->add('location')
                ->add('start_at')
                ->add('end_at')
                //->add('current')
                //->add('comment')
                //->add('liked')
                //->add('stepacquaintance')
        ;
    }

    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('Step')
                ->add('node_type', 'choice', array('choices' => UserStep::getTypeList(), 'expanded' => true, 'multiple' => false))
                ->add('node_id')
                ->add('user', 'sonata_type_model', array(), array('edit' => 'list'))
                ->add('location', 'sonata_type_model', array(), array('edit' => 'list'))
            ->end()
            ->with('Date')
                ->add('start_at')
                ->add('end_at')
                ->add('current', 'checkbox', array('required' => false))
            ->end()
            ->with('Feedback')
                ->add('comment')
                ->add('liked', 'checkbox', array('required' => false))
            ->end()
            ->with('Acquaintances')
                ->add('stepacquaintance', 'sonata_type_model', array('required' => false), array('edit' => 'list'))
            ->end()
        ;
    }
}