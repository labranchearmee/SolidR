<?php

namespace Brickstorm\HumanRoadsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BrickstormHumanRoadsBundle extends Bundle
{
}
