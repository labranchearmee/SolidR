<?php

namespace Brickstorm\Sms4FoodBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BrickstormSms4FoodBundle extends Bundle
{
}
