<?php

/*
 * This file is part of the BrickstormSms4FoodBundle package.
 *
 * (c) Brickstorm <http://brickstorm.org/>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Brickstorm\Sms4FoodBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use Brickstorm\Sms4FoodBundle\Entity\Restaurant;

use Brickstorm\Sms4FoodBundle\Manager\OrderManager;
use Brickstorm\Sms4FoodBundle\Manager\RestaurantManager;

class RestaurantController extends Controller
{

    /**
    * check connexion and go to login
    *
    */
    public function checkconnexionAction(Request $request)
    {
      return $this->render('BrickstormSms4FoodBundle:Restaurant:checkconnexion.html.twig');
    }

    /**
    * join
    *
    */
    public function joinAction(Request $request)
    {

      $em = $this->getDoctrine()->getEntityManager();
      $u  = $this->get('security.context')->getToken()->getUser();
      $r  = $this->get('session')->get('pending_restaurant') ? unserialize($this->get('session')->get('pending_restaurant')) : new Restaurant();

      $form = $this->createFormBuilder($r)
                   ->add('phonenumber', 'text')
                   ->add('hashtag', 'text')//, array('help' => $this->get('translator')->trans('form.hashtag.help')))
                   ->add('name', 'text')
                   ->add('adress', 'textarea')
                   ->add('zipcode', 'integer')
                   //->add('city')
                   ->getForm();

      if ($request->getMethod() == 'POST') {

        $form->bindRequest($request);
        if ($form->isValid()) {

          //not logged in => form
          if (!is_object($u)) {
            $this->get('session')->set('target_path', $this->get('router')->generate('manager_join'));
            $this->get('session')->set('pending_restaurant', serialize($r));
            $this->get('session')->setFlash('notice', $this->get('translator')->trans('notice.signup.new.restaurant'));

            return $this->redirect($this->get('router')->generate('fos_user_registration_register'));
          }
        }
      }

      if (is_object($u) && $r->getHashtag() && $r->getName()) {
        //save
        $r->setIsValid(false);
        $r->setUser($u);
        $em->persist($r);
        $em->flush();
        $this->get('session')->set('pending_restaurant', null);

        //add role
        $u = $this->get('security.context')->getToken()->getUser();
        $u->addRole('ROLE_NOVICE_MANAGER');
        $token = new \Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken($u, null, 'main', $u->getRoles());
        $this->get('security.context')->setToken($token);

        $this->get('session')->setFlash('success', 'restaurant.created');
        return $this->redirect($this->get('router')->generate('manager_cgvu'));
      }

      return $this->render('BrickstormSms4FoodBundle:Restaurant:join.html.twig', array(
        'form'  => $form->createView()
      ));
    }

    /**
    * cguv acceptation
    *
    * 1. accept cgvu
    * 2. new restaurant
    * 3. wait for validation
    * 4. access manager
    */
    public function cgvuAction(Request $request)
    {

      if ($request->getMethod() == 'POST') {
        if ($request->get('accepted')) {
          //redirect wait approval
          return $this->redirect($this->get('router')->generate('manager_waitapproval'));
        }

        $this->get('session')->setFlash('error', 'cgvu.not.accepted');
      }

      return $this->render('BrickstormSms4FoodBundle:Restaurant:cgvu.html.twig');
    }

    /**
    * wait for approval
    *
    */
    public function waitapprovalAction(Request $request)
    {
      //TODO : si approve => redirect

      $em = $this->getDoctrine()->getEntityManager();
      $u  = $this->get('security.context')->getToken()->getUser();
      $rs = $u->getRestaurants()->toArray();

      $form = $this->createFormBuilder(end($rs))
                   ->add('accept_takeaway', 'checkbox', array('required' => false))
                   ->add('accept_delivery', 'checkbox', array('required' => false))
                   ->add('accept_booking', 'checkbox', array('required' => false))
                   ->add('booking_range', 
                         'text',
                         array('required' => false, 
                               'attr' => array('placeholder' => $this->get('translator')->trans('form.placeholder.booking_range'))))
                   ->getForm();

      if ($request->getMethod() == 'POST') {
        $form->bindRequest($request);
        if ($form->isValid()) {
          $data = $form->getData();
          if ($data->getAcceptTakeaway() ||
              $data->getAcceptDelivery() ||
              $data->getAcceptBooking()) {
            $em->persist($data);
            $em->flush();
            $this->get('session')->setFlash('success', $this->get('translator')->trans('notice.waitapproval.update.success'));
          } else {
            $this->get('session')->setFlash('notice', $this->get('translator')->trans('notice.waitapproval.update.warning'));
          }
        }
      }

      return $this->render('BrickstormSms4FoodBundle:Restaurant:waitapproval.html.twig', array(
        'form'  => $form->createView()
      ));

    }

    /**
    * orders list
    *
    */
    public function ordersAction(Request $request)
    {
      
      $u    = $this->container->get('security.context')->getToken()->getUser();
      $rs   = $u->getRestaurants();
      $oByR = RestaurantManager::getOrdersByRestaurant($u, 
                                                       $this->getDoctrine()->getEntityManager());
      $bByR = RestaurantManager::getBookingsByRestaurant($u, 
                                                         $this->getDoctrine()->getEntityManager());

      $nb_orders = count($oByR, COUNT_RECURSIVE) - count($oByR);
      if ($nb_orders == 0) {
        $this->get('session')->setFlash('notice', $this->get('translator')->trans('manager.hasno.orders'));
      }

      return $this->render('BrickstormSms4FoodBundle:Restaurant:orders.html.twig', array(
        'restaurants' => $rs,
        'orders'      => $oByR,
        'nb_orders'   => $nb_orders,
        'nb_bookings' => count($bByR, COUNT_RECURSIVE) - count($bByR)
      ));
    }

    /**
    * bookings list
    *
    */
    public function bookingsAction(Request $request)
    {
      $u    = $this->container->get('security.context')->getToken()->getUser();
      $rs   = $u->getRestaurants();
      $oByR = RestaurantManager::getOrdersByRestaurant($u, 
                                                       $this->getDoctrine()->getEntityManager());
      $bByR = RestaurantManager::getBookingsByRestaurant($u, 
                                                         $this->getDoctrine()->getEntityManager());

      $nb_bookings = count($bByR, COUNT_RECURSIVE) - count($bByR);
      if ($nb_bookings == 0) {
        $this->get('session')->setFlash('notice', $this->get('translator')->trans('manager.hasno.bookings'));
      }

      return $this->render('BrickstormSms4FoodBundle:Restaurant:bookings.html.twig', array(
        'restaurants' => $rs,
        'bookings'    => $bByR,
        'nb_orders'   => count($oByR, COUNT_RECURSIVE) - count($oByR),
        'nb_bookings' => $nb_bookings
      ));
    }

    /**
    * home
    *
    */
    public function homeAction(Request $request)
    {
      if ($this->get('security.context')->isGranted('ROLE_MANAGER') || 
          $this->get('security.context')->isGranted('ROLE_NOVICE_MANAGER')) {
        return $this->forward('BrickstormSms4FoodBundle:User:loginDispatch');
      }

      return $this->render('BrickstormSms4FoodBundle:Restaurant:home.html.twig', array(
      ));
    }

    /**
    * settings
    *
    */
    public function settingsAction(Request $request)
    {

      $user = $this->container->get('security.context')->getToken()->getUser();
      $rs   = $user->getRestaurants();

      foreach ($rs as $r) {
        $r->form = $this->createFormBuilder($r)
                        ->add('name', 'text')
                        ->add('adress', 'textarea')
                        ->add('zipcode', 'integer')
                        ->add('city')
                        ->add('phonenumber', 'text')
                        ->add('accept_booking', 'checkbox', array('required'=> false))
                        ->add('accept_takeaway', 'checkbox', array('required'=> false))
                        ->add('accept_delivery', 'checkbox', array('required'=> false))
                        ->getForm();
      }

      return $this->render('BrickstormSms4FoodBundle:Restaurant:settings.html.twig', array(
        'restaurants' => $rs
      ));
    }

    /**
    * reporting
    *
    */
    public function reportAction(Request $request)
    {
      $user = $this->container->get('security.context')->getToken()->getUser();
      $rs   = $user->getRestaurants();

      $report = array();
      foreach ($rs as $r) {
        $rm = new RestaurantManager($r, $this->getDoctrine()->getEntityManager());
        $report[$r->getId()] = array('orders'     => $rm->getOrdersByMonth(),
                                     'bookings'   => $rm->getBookingsByMonth(),
                                     'deliveries' => $rm->getDeliveriesByMonth(),
                                     'new_users'  => $rm->getNewUsersByMonth(),
                                     );
      }

      $months = array(1 => $this->get('translator')->trans('date.month.jan'),
                      2 => $this->get('translator')->trans('date.month.feb'),
                      3 => $this->get('translator')->trans('date.month.mar'),
                      4 => $this->get('translator')->trans('date.month.apr'),
                      5 => $this->get('translator')->trans('date.month.mai'),
                      6 => $this->get('translator')->trans('date.month.jun'),
                      7 => $this->get('translator')->trans('date.month.jul'),
                      8 => $this->get('translator')->trans('date.month.aou'),
                      9 => $this->get('translator')->trans('date.month.sep'),
                      10 => $this->get('translator')->trans('date.month.oct'),
                      11 => $this->get('translator')->trans('date.month.nov'),
                      12 => $this->get('translator')->trans('date.month.dec'));

      return $this->render('BrickstormSms4FoodBundle:Restaurant:report.html.twig', array(
        'restaurants' => $rs,
        'months'      => $months,
        'report'      => $report,
      ));
    }

    /**
    * load modal
    *
    */
    public function loadModalAction(Request $request)
    {
      if (!is_numeric($request->get('id')) || !$request->get('type')) {
        return new Response('');
      }
      
      $em = $this->getDoctrine()->getEntityManager();

      switch ($request->get('type')) {
        case 'order':
          $o  = $em->getRepository('BrickstormSms4FoodBundle:Order')
                   ->findOneById($request->get('id'));
          $om = new OrderManager($o, $em, $this->get('session'));
          $om->fromSms(); // load order food
          return $this->render('BrickstormSms4FoodBundle:Restaurant:_modal_order.html.twig', array(
            'order'      => $o
          ));
        break;
        case 'booking':
          $b  = $em->getRepository('BrickstormSms4FoodBundle:Booking')
                   ->findOneById($request->get('id'));
          return $this->render('BrickstormSms4FoodBundle:Restaurant:_modal_booking.html.twig', array(
            'booking' => $b
          ));
        break;
      }
      
    }

    /**
    * load HTML for live update in the manager
    *
    */
    public function liveupdateAction(Request $request)
    {
      if (!$request->get('ids')) {
        return new Response('');
      }

      $em = $this->getDoctrine()->getEntityManager();

      $response  = null;

      switch ($request->get('type')) {
        case 'orders':
          $order_ids = array_unique($request->get('ids'));
          foreach ($order_ids as $id) {
            if (is_numeric($id)) {
              $o  = $em->getRepository('BrickstormSms4FoodBundle:Order')
                       ->findOneById($id);
              $r = $this->render('BrickstormSms4FoodBundle:Restaurant:_order.html.twig', array(
                'order' => $o
              ));
              $route = $this->get('router')->generate('manager_answerorder', array('id' => $o->getId()));
              $response .= '<tr id="answer-'.$o->getId().'" data-order-id="'.$o->getId().'" data-reload="'.$route.'" class="pending new">'.$r->getContent().'</tr>';
            }
          }
        break;
        case 'bookings':
          $booking_ids = array_unique($request->get('ids'));
          foreach ($booking_ids as $id) {
            if (is_numeric($id)) {
              $b  = $em->getRepository('BrickstormSms4FoodBundle:Booking')
                       ->findOneById($id);
              $r = $this->render('BrickstormSms4FoodBundle:Restaurant:_booking.html.twig', array(
                'booking' => $b
              ));
              $route = $this->get('router')->generate('manager_answerbooking', array('id' => $b->getId()));
              $response .= '<tr id="answer-'.$b->getId().'" data-booking-id="'.$b->getId().'" data-reload="'.$route.'" class="pending new">'.$r->getContent().'</tr>';
            }
          }
        break;
      }
      
      return new Response($response);
    }
}