<?php

/*
 * This file is part of the BrickstormSms4FoodBundle package.
 *
 * (c) Brickstorm <http://brickstorm.org/>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Brickstorm\Sms4FoodBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use Brickstorm\WorldBundle\Entity\Location;
use Brickstorm\Sms4FoodBundle\Entity\Booking;
use Brickstorm\Sms4FoodBundle\Entity\Order;
use Brickstorm\Sms4FoodBundle\Manager\OrderManager;

use Symfony\Component\Validator\Constraints\Min;
use Symfony\Component\Validator\Constraints\Max;
use Symfony\Component\Validator\Constraints\Collection;

class UserController extends Controller
{
    public function phonenumberAction(Request $request)
    {
      $u = $this->container->get('security.context')->getToken()->getUser();

      //form validation
      $collectionConstraint = new Collection(array(
          'phonenumber' => array(new Min(00000001), new Max(99999998))
      ));
      //form
      $form = $this->createFormBuilder(array('phonenumber' => $u->getPhonenumber()), array('validation_constraint' => $collectionConstraint))
                   ->add('phonenumber', 
                         'number', 
                         array('required' => true, 
                               'attr'     => array('placeholder' => $this->get('translator')->trans('form.placeholder.phonenumberwithaddon')),
                                                   'max_length'  => 8))
                   ->getForm();

      if ($request->getMethod() == 'POST') {
        $form->bindRequest($request);
        if ($form->isValid()) {
          $values = $form->getData();
          $em = $this->getDoctrine()->getEntityManager();

          //exist ?
          if (!$em->getRepository('ApplicationSonataUserBundle:User')->findOneByPhonenumber($values['phonenumber'])) {
            
            //update phonenumber
            $u->setPhonenumber($values['phonenumber']);
            $em->persist($u);
            $em->flush();
  
            $this->get('session')->setFlash('success', $this->get('translator')->trans('notice.phonenumber.success'));
            return $this->redirect($this->get('router')->generate('user_locations', array('_locale' => $this->get('session')->getLocale())));
          } else {
            $this->get('session')->setFlash('error', $this->get('translator')->trans('notice.phonenumber.exists'));
          }
        }
      }

      return $this->render('BrickstormSms4FoodBundle:User:phonenumber.html.twig', array(
        'form' => $form->createView(),
      ));
    }

    public function ordersAction(Request $request)
    {
      $u = $this->container->get('security.context')->getToken()->getUser();

      return $this->render('BrickstormSms4FoodBundle:User:orders.html.twig', array(
        'user' => $u
      ));
    }

    public function locationsAction(Request $request)
    {
      $u = $this->container->get('security.context')->getToken()->getUser();

      if (!$u->getPhonenumber()) {
        $this->get('session')->setFlash('warning', $this->get('translator')->trans('notice.phonenumber.empty'));
        return $this->redirect($this->get('router')->generate('user_phonenumber', array('_locale' => $this->get('session')->getLocale())));
      }

      $l = new Location();
      $l->setUser($u);
      $l->setPhonenumber($u->getPhonenumber());
      $form = $this->createFormBuilder($l)
                   ->add('hashtag', 
                          null, 
                          array('max_length' => 20,
                                'attr' => array('placeholder' => $this->get('translator')->trans('form.placeholder.hashtag.location'))))
                   ->add('owner')
                   ->add('adress')
                   ->add('zipcode', null, array('max_length' => 5))
                   ->add('city')
                   ->add('code')
                   ->add('more', 'textarea', array('required' => false))
                   ->getForm();

      if ($request->getMethod() == 'POST') {
        $form->bindRequest($request);
        if ($form->isValid()) {
          $l->setIsValid(0);
          $this->get('session')->setFlash('success', 'notice.location.saved');
          $em = $this->getDoctrine()->getEntityManager();
          $em->persist($l);
          $em->flush();
        }
      }

      return $this->render('BrickstormSms4FoodBundle:User:locations.html.twig', array(
        'user' => $u,
        'form' => $form->createView(),
      ));
    }

    public function bookingsAction(Request $request)
    {
      $u = $this->container->get('security.context')->getToken()->getUser();

      $b = new Booking();
      $b->setUser($u);
      $form = $this->createFormBuilder($b)
                   ->add('time')
                   ->add('nb_clients')
                   ->add('hashtag')
                   ->getForm();

      if ($request->getMethod() == 'POST') {
        $form->bindRequest($request);
        if ($form->isValid()) {
          $this->get('session')->setFlash('success', 'booking.saved');
          $em = $this->getDoctrine()->getEntityManager();
          $em->persist($b);
          $em->flush();
        }
      }

      return $this->render('BrickstormSms4FoodBundle:User:bookings.html.twig', array(
        'user' => $u,
        'form' => $form->createView(),
      ));
    }

    /**
    * dispatch user after login depending on user privileges
    */
    public function loginDispatchAction(Request $request)
    {
      if ($this->get('session')->get('target_path')) {
        return $this->redirect($this->get('session')->get('target_path'));
      } elseif ($this->get('security.context')->isGranted('ROLE_ADMIN')) {
        return $this->redirect($this->get('router')->generate('sonata_admin_dashboard'));
      } elseif ($this->get('security.context')->isGranted('ROLE_MANAGER')) {
        return $this->redirect($this->get('router')->generate('manager_orders', array('_locale' => $this->get('session')->getLocale())));
      } elseif ($this->get('security.context')->isGranted('ROLE_NOVICE_MANAGER')) {
        return $this->redirect($this->get('router')->generate('manager_waitapproval', array('_locale' => $this->get('session')->getLocale())));
      } else {
        return $this->redirect($this->get('router')->generate('user_locations', array('_locale' => $this->get('session')->getLocale())));
      }
    }

    /**
    *
    */
    public function loginCheckAction(Request $request)
    {
      
    }

    /**
    *
    */
    public function loginCheckFbconnectAction(Request $request)
    {
      
    }

    /**
    *
    */
    public function connectTwitterAction()
    {   

      $request = $this->get('request');
      $twitter = $this->get('fos_twitter.service');

      $authURL = $twitter->getLoginUrl($request);

      return $this->redirect($authURL);
    }
}