<?php
namespace Brickstorm\Sms4FoodBundle\Controller\Admin;

use Sonata\AdminBundle\Controller\CRUDController as Controller;

class FoodTypeAdminController extends Controller
{

}