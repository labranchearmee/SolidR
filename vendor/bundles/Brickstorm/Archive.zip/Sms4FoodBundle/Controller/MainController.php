<?php

/*
 * This file is part of the BrickstormSms4FoodBundle package.
 *
 * (c) Brickstorm <http://brickstorm.org/>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Brickstorm\Sms4FoodBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use Brickstorm\Sms4FoodBundle\Entity\Restaurant;
use Brickstorm\Sms4FoodBundle\Entity\Order;
use Brickstorm\Sms4FoodBundle\Entity\Booking;

use Brickstorm\Sms4FoodBundle\Manager\RestaurantManager;
use Brickstorm\Sms4FoodBundle\Manager\OrderManager;
use Brickstorm\Sms4FoodBundle\Manager\BookingManager;

//use Brickstorm\Sms4FoodBundle\Form\SmsType;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\MinLength;
use Symfony\Component\Validator\Constraints\MaxLength;
use Symfony\Component\Validator\Constraints\Regex;
use Symfony\Component\Validator\Constraints\Min;
use Symfony\Component\Validator\Constraints\Max;
use Symfony\Component\Validator\Constraints\Collection;


class MainController extends Controller
{
    public function cgvuAction(Request $request)
    {
      return $this->render('BrickstormSms4FoodBundle:Main:cgvu.html.twig');
    }
    public function apiAction(Request $request)
    {
      return $this->render('BrickstormSms4FoodBundle:Main:api.html.twig');
    }

    public function homeAction(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      $rs = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
               ->findBy(array('is_valid' => true));

      $choices = array('' => $this->get('translator')->trans('pick.one'));
      foreach ($rs as $r) {
        $choices[$r->getId()] = $r;
      }

      //refresh session
      OrderManager::reset($this->get('session'));
      BookingManager::reset($this->get('session'));

      //form validation
      $collectionConstraint = new Collection(array(
          //'email'       => new Email(),
          //'phonenumber' => array(new Min(00000001), new Max(99999998)),
          'restaurant'  => new Min(1),
          'sms'         => new Regex('/^@(\w+) (.*)/'),
      ));
      //form
      $form = $this->createFormBuilder(null, array('validation_constraint' => $collectionConstraint))
                   //->add('email', 
                   //      'email', 
                   //      array('required'      => true, 
                   //            'attr'          => array('placeholder' => $this->get('translator')->trans('form.placeholder.email')),
                   //            'property_path' => false))
                   //->add('phonenumber', 
                   //      'number', 
                   //      array('required' => true, 
                   //            'attr'     => array('placeholder' => $this->get('translator')->trans('form.placeholder.phonenumberwithaddon')),
                   //                                'max_length'  => 8))
                   ->add('restaurant', 
                         'choice', 
                         array('choices'  => $choices, 
                               'required' => true))
                   ->add('sms', 
                         'textarea', 
                         array('required' => true,
                               'attr'     => array('placeholder' => $this->get('translator')->trans('form.placeholder.sms.home'))))
                   ->getForm();

      if ($request->getMethod() == 'POST') {
        $form->bindRequest($request);
        if ($form->isValid()) {
          return $this->matchSms($request);
        }
      }

      return $this->render('BrickstormSms4FoodBundle:Main:home.html.twig', array(
        'form' => $form->createView(),
      ));
    }


    public function contactUsAction(Request $request)
    {

      //form validation
      $collectionConstraint = new Collection(array(
          'email'       => new Email,
          'phonenumber' => array(new Min(33100000001), new Max(33999999998)),
          'subject'     => new MinLength(3),
          'message'     => array(new MinLength(10), new Regex('/((.*) (.*))+/'),),
      ));
      //form
      $form = $this->createFormBuilder(null, array('validation_constraint' => $collectionConstraint))
                   ->add('email', 
                         'email', 
                         array('required' => true))
                   ->add('phonenumber', 
                         'text', 
                         array('required' => false, 
                               'attr' => array('placeholder' => $this->get('translator')->trans('form.placeholder.phonenumber')),
                                               'max_length'  => 11))
                   ->add('subject', 
                         'text', 
                         array('required'  => true))
                   ->add('message', 
                         'textarea', 
                         array('required'  => true))
                   ->getForm();

      if ($request->getMethod() == 'POST') {
        $form->bindRequest($request);
        if ($form->isValid()) {
         $values = $form->getData();
         $message = \Swift_Message::newInstance()
                ->setSubject('[SmsFood][ContactUs] '.$values['email'])
                ->setFrom($values['email'])
                ->setTo('contact@smsfood.fr')
                ->setBody(print_r($values, true));
          $this->get('mailer')->send($message);
          
          $this->get('session')->setFlash('success', $this->get('translator')->trans('notice.contact.us'));
          return $this->redirect($this->get('router')->generate('homepage'));
        }
      }

      return $this->render('BrickstormSms4FoodBundle:Main:contactUs.html.twig', array(
        'form' => $form->createView(),
      ));
    }

    /**
    * sms treatment
    *
    */
    public function matchSms(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      if (!isset($form)) {
        $form = $request->get('form');
      }

      $r  = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
                ->findOneById($form['restaurant']);
      if (!is_object($r)) {
        throw $this->createNotFoundException('sms.not.found');
      }

      if (OrderManager::matchSMS($form['sms'])) {
        return $this->forward('BrickstormSms4FoodBundle:Order:new');

      } elseif (BookingManager::matchSMS($form['sms'])) {
        return $this->forward('BrickstormSms4FoodBundle:Booking:new');

      } else {
        $this->get('session')->setFlash('error', 'sms.is.not.valid');
        return $this->redirect($this->get('router')->generate('homepage'));
      }
    }
}