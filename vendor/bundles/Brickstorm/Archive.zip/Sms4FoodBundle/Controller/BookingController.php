<?php

/*
 * This file is part of the BrickstormSms4FoodBundle package.
 *
 * (c) Brickstorm <http://brickstorm.org/>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Brickstorm\Sms4FoodBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use Brickstorm\Sms4FoodBundle\Entity\Booking;

use Brickstorm\Sms4FoodBundle\Manager\BookingManager;
use Brickstorm\Sms4FoodBundle\Manager\RestaurantManager;

class BookingController extends Controller
{
    public function deleteAction(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      $b  = $em->getRepository('BrickstormSms4FoodBundle:Booking')
               ->findOneById($request->get('id'));
      if (is_object($b)) {
        $em->remove($b);
        $em->flush();
        $this->container->get('session')->setFlash('success', 'booking.deleted');
      } else {
        $this->container->get('session')->setFlash('error', 'booking.not.exists');
      }

      return $this->redirect($this->get('router')->generate('user_bookings'));
    }

    public function saveAction(Request $request)
    {
      $u = $this->container->get('security.context')->getToken()->getUser();
      if (!is_object($u)) {
        //$this->container->get('session')->set('comefrom', $this->get('router'));
        $this->container->get('session')->set('booking.save', $request->get('form'));
        $this->container->get('session')->setFlash('notice', 'saving.booking');
        return $this->redirect($this->get('router')->generate('fos_user_security_login'));
      }

      $values = $request->get('form') ? $request->get('form') : $this->get('session')->get('booking.save');
      $em = $this->getDoctrine()->getEntityManager();
      $r  = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
               ->findOneById($values['restaurant']);

      if (!is_object($r)) {
        //throw $this->createNotFoundException('restaurant.not.exists');
        $this->get('session')->setFlash('error', 'restaurant.not.exists');
        return $this->redirect($this->get('router')->generate('homepage'));
      }
      $r->toString = 'id';
      $b = new Booking();
      $b->setRestaurant($r);
      $b->setSms($values['sms']);
      $b->setPhonenumber($this->get('translator')->trans('phonenumber.prefix').$u->getPhonenumber());

      $form = $this->createFormBuilder($b)
                   ->add('hashtag', 'text')
                   ->add('phonenumber', 'hidden')
                   ->add('sms', 'hidden')
                   ->add('nb_clients', 'hidden')
                   ->add('time', 'hidden')
                   ->add('restaurant', 'hidden')
                   ->getForm();

      if ($request->get('do_save')) {
        $b->setHashtag($values['hashtag']);
        $b->setUser($u);

        $om = new BookingManager($b, $em, $this->get('session'));
        $om->fromSms($values['sms']);
        print_r($values['sms']);
  
        $em->persist($b);
        $em->flush();

        $this->get('session')->setFlash('success', 'notice.booking.saved');
        return $this->redirect($this->get('router')->generate('user_bookings'));
      }

      return $this->render('BrickstormSms4FoodBundle:Booking:save.html.twig', array(
        'booking' => $b,
        'form'    => $form->createView()
      ));
    }

    public function loadAction(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      $b  = $em->getRepository('BrickstormSms4FoodBundle:Booking')
               ->findOneById($request->get('id'));
      if (!is_object($b)) {
          throw $this->createNotFoundException('booking.not.exists');
      }

      return $this->render('BrickstormSms4FoodBundle:Restaurant:_booking.html.twig', array(
        'booking' => $b,
      ));
    }
  
    /**
    * answer an order
    */
    public function answerAction(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      $b  = $em->getRepository('BrickstormSms4FoodBundle:Booking')
               ->findOneById($request->get('id'));
      if (!is_object($b)) {
          throw $this->createNotFoundException('booking.not.exists');
      }

      if ($request->getMethod() == 'POST') {
        $bm = new BookingManager($b, $em, $this->get('session'));
        $bm->answer($request->get('answer'), $this->container);
      }

      return new Response(json_encode(array('state' => $b->getState(), 
                                            'id'    => $request->get('id'), 
                                            'url'   => $this->get('router')->generate('manager_loadbooking', 
                                                                                      array('id' => $request->get('id'))))));
    }

    /**
    * create an order
    */
    public function newAction(Request $request)
    {
      $b = new Booking();
      $form = $this->createFormBuilder($b)
                   ->add('hashtag', 'text')
                   ->add('phonenumber', 'hidden')
                   ->add('sms', 'hidden')
                   ->add('restaurant', 'hidden')
                   ->getForm();

      if ($request->getMethod() == 'POST') {
        $form->bindRequest($request);
        $data = $form->getData();
        //print_r($data);exit();
        $em = $this->getDoctrine()->getEntityManager();
        $r  = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
                 ->findOneById($data['restaurant']);
        if (!is_object($r)) {
          //throw $this->createNotFoundException('restaurant.not.exists');
          $this->get('session')->setFlash('error', 'restaurant.not.exists');
          return $this->redirect($this->get('router')->generate('homepage'));
        }

        $bm = new BookingManager($b, $em, $this->get('session'));
        $bm->fromSms($data['sms']);


        //invalid ?
        if (!$form->isValid() || !$bm->matchSMS($b)) {
          $this->get('session')->setFlash('error', 'booking.is.not.valid');
          return $this->redirect($this->get('router')->generate('homepage'));
        }

        $em->persist($b);
        $em->flush();

        //send sms
        $brickstormsms = $this->get('brickstorm.sms');
        $brickstormsms->send('SmsFood : nouvelle réservation', $bm->toSms(), $o->getPhonenumber());
      }

      return $this->render('BrickstormSms4FoodBundle:Booking:confirm.html.twig', array(
        'booking' => $b,
      ));
    }

    public function updateAction(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      $r  = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
               ->findOneById($request->get('restaurant_id'));

      if (!is_object($r)) {
          throw $this->createNotFoundException('restaurant.not.exists');
      }

      $b = new Booking();
      $b->setRestaurant($r);

      $om = new BookingManager($b, $em, $this->get('session'));
      //$om->fromSms($request->get('sms'));
      $om->fromSms($request->get('food_hashtag'), true); //update

      return new Response(json_encode(array('sms'   => $om->toSms())));
    }
    
}