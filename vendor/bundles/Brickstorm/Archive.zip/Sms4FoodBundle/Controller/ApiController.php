<?php

/*
 * This file is part of the BrickstormSms4FoodBundle package.
 *
 * (c) Brickstorm <http://brickstorm.org/>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Brickstorm\Sms4FoodBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use Brickstorm\Sms4FoodBundle\Entity\Restaurant;
use Brickstorm\Sms4FoodBundle\Entity\Order;
use Brickstorm\Sms4FoodBundle\Entity\Booking;

use Brickstorm\Sms4FoodBundle\Manager\RestaurantManager;
use Brickstorm\Sms4FoodBundle\Manager\OrderManager;
use Brickstorm\Sms4FoodBundle\Manager\BookingManager;

class ApiController extends Controller
{
    /**
    * new order
    *
    */
    public function neworderAction(Request $request)
    {
      //TODO
    }
    /**
    * new booking
    *
    */
    public function newbookingAction(Request $request)
    {
      //TODO
    }
    /**
    * cancel order
    *
    */
    public function cancelorderAction(Request $request)
    {
      //TODO
    }
    /**
    * cancel booking
    *
    */
    public function cancelbookingAction(Request $request)
    {
      //TODO
    }

    /**
    * restaurant list of orders
    *
    */
    public function liveupdateAction(Request $request)
    {
      //from restaurant
      if ($request->get('id')) {
        $em = $this->getDoctrine()->getEntityManager();
        $r  = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
                 ->findOneById($request->get('id'));
        if (!is_object($r)) {
          throw $this->createNotFoundException('restaurant.not.found');
        }

        $timestamp = date('Y-m-d H:i:s', $request->get('since')/1000);
        //echo $timestamp;
        //orders
        $qb = $em->createQueryBuilder();
        $qb->add('select', 'o')
           ->add('from', 'BrickstormSms4FoodBundle:Order o')
           ->add('where', $qb->expr()->andx(
                              $qb->expr()->eq('o.restaurant', '?1'),
                              $qb->expr()->gt('o.created_at', '?2')
                           )
                 )
           ->andWhere('o.completed_at is null')
           ->setParameter(1, $r)
           ->setParameter(2, $timestamp)
           ->orderBy('o.created_at', 'DESC');
        $query = $qb->getQuery();
        $orders = $query->getResult();

        //bookings
        $qb = $em->createQueryBuilder();
        $qb->add('select', 'b')
           ->add('from', 'BrickstormSms4FoodBundle:Booking b')
           ->add('where', $qb->expr()->andx(
                              $qb->expr()->eq('b.restaurant', '?1'),
                              $qb->expr()->gt('b.created_at', '?2')
                           )
                 )
           ->andWhere('b.accepted_at is null')
           ->setParameter(1, $r)
           ->setParameter(2, $timestamp)
           ->orderBy('b.created_at', 'DESC');
        $query = $qb->getQuery();
        $bookings = $query->getResult();

        return $this->render('BrickstormSms4FoodBundle:Api:objects.html.twig', array(
          'objects' => array('orders' => $orders, 'bookings' => $bookings, 'since' => $timestamp),
        ));
      }
    }

    /**
    * restaurant list of bookings
    *
    */
    public function bookingsAction(Request $request)
    {
      //from restaurant
      if ($request->get('id')) {
        $em = $this->getDoctrine()->getEntityManager();
        $r  = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
                 ->findOneById($request->get('id'));
        if (!is_object($r)) {
          throw $this->createNotFoundException('restaurant.not.found');
        }

        $qb = $em->createQueryBuilder();
        $qb->add('select', 'b')
           ->add('from', 'BrickstormSms4FoodBundle:Booking b')
           ->add('where', $qb->expr()->andx(
                              $qb->expr()->eq('b.restaurant', '?1'),
                              $qb->expr()->gt('b.id', '?2')
                           )
                 )
           ->andWhere('b.completed_at is null')
           ->setParameter(1, $r)
           ->setParameter(2, $request->get('since_order_id', 0))
           ->orderBy('b.created_at', 'DESC');

        $query = $qb->getQuery();

        return $this->render('BrickstormSms4FoodBundle:Api:objects.html.twig', array(
          'objects' => $query->getResult(),
        ));
      }
    }

    /**
    * sms capture
    * 
    *  <inbox>
    *  <sms from=\" 0000000000\" to=\" 0000000000\" date=\"2011-06-01
    *  12:02:07\"><![CDATA[My message 1]]></sms>
    *  <sms from=\" 1111111111\" to=\" 0000000000\" date=\"2011-06-01
    *  12:02:08\"><![CDATA[My message 2]]></sms>
    *  </inbox>
    *
    */
    public function catchSMSAction(Request $request)
    {
      
      $xml_from_request = trim($request->request->get('XML') ? $request->request->get('XML') : $request->get('INJECTXML'));

      //hack
      if (substr($xml_from_request, -8) != '</inbox>') {
        $xml_from_request .= ' - ERREUR : le SMS a été coupé ! ]]></sms></inbox>';
      }

      mail('bbergstorm@gmail.com', 'catchSMS', ' XML:'.$xml_from_request);

      if (!$xml_from_request) {
        return new Response('{"success":0,"error":"no xml"}');
      } 

      //TODO : phoneumber blacklist

      //echo $request->get('XML');exit();
      $xml = simplexml_load_string(urldecode($xml_from_request));

      if (!$xml) {
        return new Response('{"success":0,"error":"xml invalid"}');
      }

      $em = $this->getDoctrine()->getEntityManager();
      $success = 0;
      foreach ($xml->children() as $sms) {

        //find restaurant ?
        $rm = new RestaurantManager(new Restaurant(), $em);
        if ($r = $rm->fromSms($sms)) {

          // -- find confirmation
          if (is_numeric((string)$sms)) {

          // -- find booking
          } elseif (BookingManager::matchSMS((string)$sms)) {
            $b = new Booking();
            $b->setRestaurant($r);
            $b->setPhonenumber($sms->attributes()->from);
            if ($u = $em->getRepository('ApplicationSonataUserBundle:User')->findOneByPhonenumber($sms->attributes()->from)) {
              $b->setUser($u);
            }
            $bm = new BookingManager($b, $em, $this->get('session'));
            $bm->fromSms((string)$sms);
            //valid ?
            if ($bm->validate($b)) {
              $em->persist($b);
              $em->flush();

              //send welcome sms
              if ($bm->isFirstOne($b)) {
                $brickstormsms = $this->get('brickstorm.sms');
                $brickstormsms->send('SmsFood',
                                     $this->get('translator')->trans('sms.first.booking.welcome.content', 
                                                                     array('%sms%'        => $om->toSms(),
                                                                           '%restaurant%' => $o->getRestaurant()->getName())),
                                     $b->getPhonenumber());
              }

              $success++;
            } else {
              return new Response('{"success":0,"Booking":"validation failure","sms":"'.(string)$sms.'"}');
            }

          // -- find order
          } elseif (OrderManager::matchSMS((string)$sms)) {
            $o = new Order();
            $o->setRestaurant($r);
            $o->setPhonenumber($sms->attributes()->from);
            if ($u = $em->getRepository('ApplicationSonataUserBundle:User')->findOneByPhonenumber($sms->attributes()->from)) {
              $o->setUser($u);
            }
            $om = new OrderManager($o, $em, $this->get('session'));
            $om->fromSms((string)$sms, false, false);
            //valid ?
            if ($om->validate($o)) {
              $em->persist($o);
              $em->flush();

              //send welcome sms
              if ($om->isFirstOne($o)) {
                $brickstormsms = $this->get('brickstorm.sms');
                $brickstormsms->send('SmsFood',
                                     $this->get('translator')->trans('sms.first.order.welcome', 
                                                                     array('%sms%'        => $om->toSms(),
                                                                           '%restaurant%' => $o->getRestaurant()->getName())),
                                     $o->getPhonenumber());
              }

              $success++;
            } else {
              return new Response('{"success":0,"Order":"validation failure","sms":"'.(string)$sms.'"}');
            }

          // -- fail
          } else {
            $brickstormsms = $this->get('brickstorm.sms');
            $brickstormsms->send('SmsFood',
                                  $this->get('translator')->trans('sms.catch.failure.restaurant',
                                                                  array('%restaurant%' => $r->getName())),
                                  $sms->attributes()->from);
          
          }
        } else {
          $brickstormsms = $this->get('brickstorm.sms');
          $brickstormsms->send('SmsFood',
                                $this->get('translator')->trans('sms.catch.failure.nothing'),
                                $sms->attributes()->from);
        
        }
      }

      //return
      if ($success) {
        return new Response('{"success":1,"nb_sms_found":"'.$success.'","type":"'.(isset($b) ? 'booking' : 'order').'"}');
      } else {
        return new Response('{"success":0,"restaurant":"'.$r.'"}');
      }
    }

    /**
    * hack : execute cron from php
    */
    public function cronAction () {
      $input = new \Symfony\Component\Console\Input\ArgvInput(array('pending_time'=> 300));
      //$input->setArgument('pending_time', 300);
      $output = new \Symfony\Component\Console\Output\ConsoleOutput();
      
      $command = $this->get('brickstorm.sms4foodcron');
      $returnCode = $command->execute($input, $output);

      echo 'HERE';exit();
      return new Response($returnCode);
    }
    
}