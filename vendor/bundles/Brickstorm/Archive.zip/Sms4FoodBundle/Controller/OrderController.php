<?php

/*
 * This file is part of the BrickstormSms4FoodBundle package.
 *
 * (c) Brickstorm <http://brickstorm.org/>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Brickstorm\Sms4FoodBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use Brickstorm\Sms4FoodBundle\Entity\Order;

use Brickstorm\Sms4FoodBundle\Manager\OrderManager;
use Brickstorm\Sms4FoodBundle\Manager\RestaurantManager;

class OrderController extends Controller
{

    /**
    * delete an order
    */
    public function deleteAction(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      $o  = $em->getRepository('BrickstormSms4FoodBundle:Order')
               ->findOneById($request->get('id'));
      if (is_object($o)) {
        $em->remove($o);
        $em->flush();
        $this->container->get('session')->setFlash('success', 'order.deleted');
      } else {
        $this->container->get('session')->setFlash('error', 'order.not.exists');
      }

      return $this->redirect($this->get('router')->generate('user'));
    }

    /**
    * save an order
    */
    public function saveAction(Request $request)
    {
      $u = $this->container->get('security.context')->getToken()->getUser();
      if (!is_object($u)) {
        $this->get('session')->set('comefrom', $this->get('router')->generate('order_save'));
        $this->get('session')->set('order.save', $request->get('form'));
        $this->get('session')->setFlash('notice', 'saving.order');
        return $this->redirect($this->get('router')->generate('fos_user_security_login'));
      }

      $values = $request->get('form') ? $request->get('form') : $this->get('session')->get('order.save');
      $em = $this->getDoctrine()->getEntityManager();
      $r  = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
               ->findOneById($values['restaurant']);

      if (!is_object($r)) {
        //throw $this->createNotFoundException('restaurant.not.exists');
        $this->get('session')->setFlash('error', 'restaurant.not.exists');
        return $this->redirect($this->get('router')->generate('homepage'));
      }

      $r->toString = 'id';
      $o = new Order();
      $o->setRestaurant($r);
      $o->setSms($values['sms']);
      $o->setUser($u);
      $o->setPhonenumber($u->getPhonenumber());

      $form = $this->createFormBuilder($o)
                   ->add('hashtag', 'text')
                   ->add('phonenumber', 'hidden')
                   ->add('sms', 'hidden')
                   ->add('restaurant', 'hidden')
                   ->getForm();

      if ($request->get('do_save')) {
        $o->setHashtag($values['hashtag']);

        $om = new OrderManager($o, $em, $this->get('session'));
        $om->fromSms($values['sms']);

        $em->persist($o);
        $em->flush();

        $om->fromSms($values['sms']); //again, will save OrderFoods as the order is in database now

        $this->get('session')->setFlash('success', 'notice.order.saved');
        return $this->redirect($this->get('router')->generate('user_orders'));
      }

      return $this->render('BrickstormSms4FoodBundle:Order:save.html.twig', array(
        'order' => $o,
        'form'  => $form->createView()
      ));
    }

    /**
    * load an order in manager
    */
    public function loadAction(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      $o  = $em->getRepository('BrickstormSms4FoodBundle:Order')
               ->findOneById($request->get('id'));
      if (!is_object($o)) {
          throw $this->createNotFoundException('order.not.exists');
      }

      return $this->render('BrickstormSms4FoodBundle:Restaurant:_order.html.twig', array(
        'order' => $o,
      ));
    }

    /**
    * answer an order
    */
    public function answerAction(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      $o  = $em->getRepository('BrickstormSms4FoodBundle:Order')
               ->findOneById($request->get('id'));
      if (!is_object($o)) {
          throw $this->createNotFoundException('order.not.exists');
      }

      if ($request->getMethod() == 'POST') {
        $om = new OrderManager($o, $em, $this->get('session'));
        $om->answer($request->get('answer'), $request->get('delay'), $this->container);
      }

      return new Response(json_encode(array('state' => $o->getState(), 
                                            'id'    => $request->get('id'), 
                                            'url'   => $this->get('router')->generate('manager_loadorder', 
                                                                                      array('id' => $request->get('id'))))));
    }

    /**
    * create an order
    */
    public function newAction(Request $request)
    {
      
      $em = $this->getDoctrine()->getEntityManager();
      $form = $request->get('form');
      $r  = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
                ->findOneById($form['restaurant']);
      if (!is_object($r)) {
        //throw $this->createNotFoundException('restaurant.not.exists');
        $this->get('session')->setFlash('error', 'restaurant.not.exists');
        return $this->redirect($this->get('router')->generate('homepage'));
      }

      $o = new Order();
      $o->setRestaurant($r);

      $form = $this->createFormBuilder($o)
                   ->add('hashtag', 'text')
                   ->add('phonenumber', 'hidden')
                   ->add('sms', 'hidden')
                   //->add('restaurant', 'hidden')
                   ->getForm();

      if ($request->getMethod() == 'POST') {
        $form->bindRequest($request);
        $data = $form->getData();

        $om = new OrderManager($data, $em, $this->get('session'));
        $om->fromSms();

        //invalid ?
        if (!$om->matchSMS($o->getSms())) {
          $this->get('session')->setFlash('error', 'order.is.not.valid');
          return $this->redirect($this->get('router')->generate('homepage'));
        }

        $em->persist($o);
        $em->flush();

        //send sms
        $brickstormsms = $this->get('brickstorm.sms');
        $brickstormsms->send('SmsFood : nouvelle commande', $om->toSms(), $o->getPhonenumber());
      }

      return $this->render('BrickstormSms4FoodBundle:Order:confirm.html.twig', array(
        'order' => $o,
      ));
    }

    /**
    * update order
    */
    public function updateAction(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      $u  = $this->container->get('security.context')->getToken()->getUser();
      $r  = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
               ->findOneById($request->get('restaurant_id'));

      if (!is_object($r)) {
          throw $this->createNotFoundException('restaurant.not.exists');
      }

      $o = new Order();
      $o->setRestaurant($r);
      if (is_object($u)) {
        $o->setUser($u);
        $o->setPhonenumber($u->getPhonenumber());
      }

      $om = new OrderManager($o, $em, $this->get('session'));
      //$om->fromSms($request->get('sms'));
      $om->fromSms($request->get('food_hashtag'), true); //update

      return new Response(json_encode(array('sms'   => $om->toSms())));
    }

    /**
    * get restaurant menu
    */
    public function menuAction(Request $request)
    {
      $em = $this->getDoctrine()->getEntityManager();
      $r  = $em->getRepository('BrickstormSms4FoodBundle:Restaurant')
               ->findOneById($request->get('id'));
      if (!is_object($r)) {
          throw $this->createNotFoundException('restaurant.not.exists');
      }

      $om = new RestaurantManager($r, $em);
      $fts = $om->getFoodtypes();

      return $this->render('BrickstormSms4FoodBundle:Order:_menu.html.twig', array(
        'restaurant' => $r,
        'foodtypes'  => $fts,
      ));
    }
}