// -- helpers
//progressbar
progressbar = '<div id="progressbar" class="progress progress-striped active"><div class="bar" style="width: 0%; "></div></div>';
function startProgressbar(count) {
  count++;count++;
  $('#progressbar .bar').css('width', count+'%');
  if (count<100) {setTimeout(function() { startProgressbar(count)},100);}
}
//animate highlight
$.fn.animateHighlight = function(toColor, duration, timeout) {
    var toColor = toColor || "#FFFF9C";
    var fromColor = this.css("backgroundColor");
    var animateMs = duration || 1500;

    if (timeout > 0) {
      animateHighlightOriginalBg = fromColor;
      animateHighlightToStop = this;
      setTimeout(function(){  animateHighlightToStop.stop().css("background-color", animateHighlightOriginalBg); }, timeout)
    }

    this.animate({backgroundColor: toColor}, 
                  animateMs, 
                  "linear", 
                  function() {
                    $(this).animateHighlight(fromColor, duration, 0);
                  });
};

// -- manager class
var B_SF_manager;
B_SF_manager = {
  type: null,
  init: function() {
    console.log('B_SF_manager', 'ON', 'url:'+$('.manager-liveupdate').data('url-api'));
    var self = this;

    //type
    this.type = $('#bookings').html() ? 'bookings' : 'orders';

    //live update
    self.updateTime();
    setTimeout(function(){self.checkForUpdate($('.manager-liveupdate').data('url-api'));}, 15000);

    //answers
    $('.btn-group a[rel]').live('click', function(){
      console.log('.btn-group a[rel]', 'live clic');
      self.answer($(this).data('id'), $(this).attr('rel'), $(this).data('delay'));
    });

    //menu
    $('#toggle span').click(function(){
      $('#toggle span.selected').removeClass('selected');
      $(this).addClass('selected')
      if ($(this).data('toggle')) {
        $('.manager-liveupdate tr').hide();
        $('.manager-liveupdate tr.'+$(this).data('toggle')).fadeIn();
      } else {
        $('.manager-liveupdate tr').show();
      }
    });
  },
  answer: function(answerid, answer, delay) {
    console.log('B_SF_manager.answer', answerid, answer, delay, $('tr#answer-' + answerid).data('reload'));
    $('tr#answer-' + answerid).html('<td colspan="2">'+progressbar+'</td>');startProgressbar(0);
    $.post($('tr#answer-' + answerid).data('reload'),
        { id: answerid,
          answer: answer,
          delay: delay
        },
        function(data){
          console.log('data', data, data.paywall);
          
          if (typeof data.paywall != "undefined") {
            //TO ADD : add paywall
          } else {
            $('tr#answer-' + data.id).fadeOut('slow').load(data.url).attr('class', data.state+(data.state=='completed'?' hide':'')).fadeIn('slow');
          }
        },
        "json");
  },
  loadNew: function(type, ids) {
    if (ids.length > 0) {
      $.post($('#'+type).data('url-liveupdate'),
            {
              ids: ids
            },
            function(html){
              if (html) {
                //insert html
                $('#'+type).prepend(html);
              }
            },
            "html");
    }
  },
  updateTime: function() {
    var d = new Date();
    this.time_last_update = d.getTime();
  },
  checkForUpdate: function(url) {

    var self = this;
    console.log('checkForUpdate', 'time_last_update:' + self.time_last_update);
    $.ajaxSetup({ async: false });
    $.post(url,
            {
              id: $('.manager-liveupdate').data('restaurant-id'),
              since: self.time_last_update,
            },
            function(data){
              console.log('data', data);
              
              self.updateTime();
              
              //get booking_ids
              var booking_ids = new Array();
              for (i=0;i<data.bookings.length;i++) {
                if (!$('#orders tr#booking-'+data.bookings[i].id).html()) {
                  booking_ids[i] = data.bookings[i].id;
                }
              }
              console.log('booking_ids', booking_ids);

              //trigger bookings
              if (booking_ids.length > 0) {
                $('#badge-bookings .badge').html(booking_ids.length).addClass('badge-important');
                $('#trigger-new-booking .trigger-count').html(booking_ids.length);
                $('#trigger-new-booking').fadeIn();
                $('#trigger-new-booking').unbind().click(function(e){
                  e.preventDefault();
                  //TO ADD : paywall
                  //load bookings
                  if (self.type == 'bookings') {
                    self.loadNew('bookings', booking_ids);
                  } else {
                    document.location = 'orders'
                  }
                  $(this).fadeOut();
                  $('#badge-bookings .badge').removeClass('badge-important');
                });
                //visual alert
                $('#trigger-new-booking').animateHighlight("#dd0000", 3000, 15000);
                //audioalert
                $("#trigger-new-booking .trigger-sound")[0].play();
              }

              //get order_ids
              var order_ids = new Array();
              for (i=0;i<data.orders.length;i++) {
                if (!$('#orders tr#order-'+data.orders[i].id).html()) {
                  order_ids[i] = data.orders[i].id;
                }
              }
              console.log('order_ids', order_ids);

              //trigger orders
              if (order_ids.length > 0) {
                $('#badge-orders .badge').html(order_ids.length).addClass('badge-important');
                $('#trigger-new-order .trigger-count').html(order_ids.length);
                $('#trigger-new-order').fadeIn();
                $('#trigger-new-order').unbind().click(function(e){
                  e.preventDefault();
                  //TO ADD : paywall
                  //load orders
                  if (self.type == 'orders') {
                    self.loadNew('orders', order_ids);
                  } else {
                    document.location = 'bookings'
                  }
                  $(this).fadeOut();
                  $('#badge-orders .badge').removeClass('badge-important');
                });
                //visual alert
                $('#trigger-new-order').animateHighlight("#dd0000", 3000, 15000);
                //audioalert
                $("#trigger-new-order .trigger-sound")[0].play();
              }
            },
            "json");

     setTimeout(function(){self.checkForUpdate(url);}, 15000);
  }
}

// -- manager class
var B_SF_smshowto;
B_SF_smshowto = {
  restaurant_id: null,
  init: function() {
    console.log('B_SF_smshowto', 'ON');
    var self = this;

    self.prepare();

    //select restaurant
    $('#start-order select').change(function(){
      
      $('#sms-helper').fadeOut();
      $('#easy-order').removeClass('with-menu');

      self.restaurant_id = $(this).val();
      if ($(this).val()) {
        console.log('B_SF_smshowto init', 'restaurant:' + $(this).val());
        self.loadMenu($('#start-order').data('menu'), $(this).val());
      }
      $('#easy-order').removeClass('with-menu');
    });

    //submit
    $('#start-order input[type=submit]').click(function(){
      if ($('#modal-easy-order').css('display') == 'block') {
        return true;
      }
      $('#modal-easy-order #modal-sms').html($('#form_sms').val());
      $('#modal-easy-order').modal({backdrop:'static'});
      return false;
    });

    //save
    $('#save').click(function(){
      var type = $('#sms-type li.active a').data('type');
      //var action = $('#start-order').attr('action');
      console.log('type', type, $('#start-order').data('save-' + type));
      
      $('#start-order').attr('action', $('#start-order').data('save-' + type));
      $('#start-order').submit();
      //$('#start-order').attr('action', action); //if not submitted
    });
  },
  updateSms: function(type, restaurant_id, sms_hashtag) {
    console.log('sms_hashtag:'+sms_hashtag,'restaurant_id:'+restaurant_id,'url:'+$('#start-order').data('update-' + type));
    $.post($('#start-order').data('update-' + type),
            {
              restaurant_id: restaurant_id,
              food_hashtag: sms_hashtag,
            },
            function(data){
              console.log('updateOrder > data', data);
              $('#start-order textarea').attr('value', data.sms);
            },
            "json");
  },
  prepare: function() {
    var self = this;
    console.log('restaurant_id',self.restaurant_id);

    // -- booking
    //tabs
    $('#tabbooking select#count').change(function(){
      console.log('updateOrder', self.restaurant_id, $(this).val());
      self.updateSms('booking', self.restaurant_id, $(this).val());
    });
    $('#tabbooking select.time').change(function(){
      var h = $('#tabbooking #time-h').val();
      var m = $('#tabbooking #time-m').val();
      console.log('updateOrder', self.restaurant_id, h + ':' + m);
      self.updateSms('booking', self.restaurant_id, h + ':' + m);
    });
    
    // -- order
    //order delivery
    $('select#delivery').change(function(){
      hashtag = ' #' + ($('select#delivery').val() ? $('select#delivery').val() : '__remove');
      self.updateSms('order', self.restaurant_id, hashtag);
    });
    
    // -- booking
    $('input#booking').change(function(){
      hashtag = ' #' + ($('select#delivery').val() ? $('select#delivery').val() : '__remove');
      self.updateSms('order', self.restaurant_id, hashtag);
    });
  },
  reset: function(data) {
    $('#orderoptions').show();
    $('#sms-type a:first').attr('href', '#taborder');
    $('#sms-type a:last').attr('href', '#tabbooking');
    
    //hide booking
    if (!data.restaurant.accept_takeaway && !data.restaurant.accept_delivery) {
      $('#sms-type a:first').attr('href', '#unvailable');
    }
    //hide orders
    if (!data.restaurant.accept_booking) {
      $('#sms-type a:last').attr('href', '#unvailable');
    }
    //hide delivery
    if (!data.restaurant.accept_delivery) {
      $('#orderoptions').hide();
    }
  },
  loadMenu: function(url, restaurant_id) {
    var self = this;
    console.log('B_SF_smshowto.loadMenu:' + url);
    $.post(url,
           { id: restaurant_id },
           function(data){
              console.log('data', data);
              
              // textarea
              $('#start-order textarea').attr('value', '@' + data.restaurant.hashtag);
              //reset html
              self.reset(data);
              //menu
              $('#cart').html(data.html);
              //order food
              $('#cart .btn').click(function(){
                var food_hashtag = $(this).parent().parent().parent().attr('id');
                hashtag = ' ' + ($(this).find('i').hasClass('icon-minus') ? '-1#' + food_hashtag : '1#' + food_hashtag);
                if ($('select#delivery').val()) {
                  hashtag += ' #' + $('select#delivery').val();
                }
                self.updateSms('order', self.restaurant_id, hashtag);
              });
              $('#cart span[rel=tooltip]').tooltip();
              //menu type loader
              $('ul#menu-type-loader a').click(function(){
              if ($(this).data('typeid') == 'all') {
                $('table#menu-list tr').fadeIn();
              } else {
                $('table#menu-list tr').hide();
                $('table#menu-list tr.type-' + $(this).data('typeid')).fadeIn();
              }
              });
              $('#easy-order').addClass('with-menu');
              $('#sms-helper').fadeIn('slow');
              
           },
           "json");
  }
  
}


// -- onload

//hack FOSUserBundle
$(document).ready(function() {
  $('#_submit').addClass('btn btn-info');
  
  //tooltip
  $('a[rel=tooltip]').tooltip();
  
  //manager
  if ($('#init-manager').html()) {
    B_SF_manager.init();
  }
  
  //homepage
  if ($('#start-order').html()) {
    B_SF_smshowto.init();
  }
  
  //manager booking range
  if ($('.btn-group label[for=form_accept_booking]')) {
    $('.btn-group label[for=form_accept_booking]:first').click(function(){
        console.log('form_accept_booking');
      $('#form div:last').fadeIn();
    });
    $('.btn-group label[for=form_accept_booking]:last').click(function(){
        console.log('form_refuse_booking');
      $('#form div:last').fadeOut();
    });
  }

  //modals
  // Support for AJAX loaded modal window.
  // Focuses on first input textbox after it loads the window.
  $('[data-toggle="modal"]').live('click', function(e) {
  	e.preventDefault();
  	if (!$(this).data('url')) {
  		$(this).modal();
  	} else {
  	 var trigger = this;
  	 console.log(trigger);
  		$.post($(this).data('url'),
  		        {},
  		       function(html) {
          		 $('div.modal-body').html(html);
          	   trigger.modal();
          	 })
  	}
  });
});