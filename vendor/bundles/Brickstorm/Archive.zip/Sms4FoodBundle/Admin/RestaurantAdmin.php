<?php
namespace Brickstorm\Sms4FoodBundle\Admin;

use Sonata\AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;

use Knplabs\Bundle\MenuBundle\MenuItem;

use Brickstorm\Sms4FoodBundle\Entity\Restaurant;

class RestaurantAdmin extends Admin
{
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->addIdentifier('name')
        ;
    }

    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
                ->add('name')
                ->add('hashtag')
                ->add('phonenumber')
                ->add('user')
                ->add('is_valid', 'checkbox', array('required' => false))
                ->add('accept_booking', 'checkbox', array('required' => false))
                ->add('accept_takeaway', 'checkbox', array('required' => false))
                ->add('accept_delivery', 'checkbox', array('required' => false))
                ->add('areas', 'sonata_type_model', array('required' => false), array('multiple' => true))
            ->end()
            ->with('Menu')
                ->add('foods', 'sonata_type_model', array('required' => false), array('multiple' => true))
            ->end()
            ->with('Location')
                ->add('adress')
                ->add('city')
                ->add('zipcode')
            ->end()
            ->with('Booking')
                ->add('booking_range')
            ->end()
        ;
    }

}