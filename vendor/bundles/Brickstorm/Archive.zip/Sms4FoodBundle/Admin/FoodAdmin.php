<?php
namespace Brickstorm\Sms4FoodBundle\Admin;

use Sonata\AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;

use Knplabs\Bundle\MenuBundle\MenuItem;

use Brickstorm\Sms4FoodBundle\Entity\Food;

class FoodAdmin extends Admin
{
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->addIdentifier('name')
        ;
    }

    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('Food')
                ->add('name')
                ->add('price', 'number', array('required' => false))
                ->add('description', 'textarea', array('required' => false))
                ->add('foodtype')
            ->end()
            ->with('General')
                ->add('restaurant')
                ->add('hashtag')
                //->add('orderfoods', 'sonata_type_model', array('required' => false), array('multiple' => true))
            ->end()
        ;
    }
}