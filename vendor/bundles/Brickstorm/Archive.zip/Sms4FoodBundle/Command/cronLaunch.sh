#!/bin/bash

cd /homez.307/amndrc/www/__brickstorm/Sms4Food

for x in $(seq 3300 -60 0)    
do    
  echo "x = $x"
  #php.ORIG.5.3.10 app/console smsfood:cron --env=prod
  /usr/local/bin/php.TEST.5 -c /usr/local/lib/php.ini app/console smsfood:cron --env=prod
  sleep 60
done 
