<?php

namespace Brickstorm\Sms4FoodBundle\Command;

set_time_limit(36000);

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

use Brickstorm\Sms4FoodBundle\Manager\OrderManager;
use Brickstorm\Sms4FoodBundle\Entity\Order;
use Brickstorm\Sms4FoodBundle\Manager\BookingManager;
use Brickstorm\Sms4FoodBundle\Entity\Booking;

class cronCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('smsfood:cron')
            ->setDescription('check/update orders')
            ->addArgument('pending_time', InputArgument::OPTIONAL, 'nb of minutes to check in the past')
            //->addOption('yell', null, InputOption::VALUE_NONE, 'If set, the task will yell in uppercase letters')
        ;
    }

    /**
    * 
    *
    *
    */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
      //mail('bbergstorm@gmail.com', 'smsFood : cronCommand', 'Command execute ');
      $this->em      = $this->getContainer()->get('doctrine')->getEntityManager();
      $this->output  = $output;
      
      //init session manager
      $this->manager_alerted_orders = array();
      $this->manager_alerted_bookings = array();
      if ($manager_alerted_orders = $this->getContainer()->get('session')->get('manager_alerted_orders')) {
        $this->manager_alerted_orders = $manager_alerted_orders;
      }
      if ($manager_alerted_bookings = $this->getContainer()->get('session')->get('manager_alerted_bookings')) {
        $this->manager_alerted_bookings = $manager_alerted_bookings;
      }

      //run every minute for one hour
      $endtime = time() + 3600;
      //while (time() < $endtime) {

        $output->writeln('<comment>time: ' . time() . '</comment>');
        $this->checkOrders($input->getArgument('pending_time'));
        $this->checkBookings($input->getArgument('pending_time'));

      //  sleep(60);
      //}
    }

    /**
    * check pending orders without answer
    *
    *
    */
    protected function checkOrders($pending_time)
    {
      $manager_delay    = (OrderManager::MAX_PENDING_TIME_ORDER - OrderManager::MAX_PENDING_TIME_MANAGER) / 60;
      //mail('bbergstorm@gmail.com', 'smsFood : cronCommand > checkOrders', $manager_delay);
      $manager_to_alert = array();
      $orders           = OrderManager::getPending($this->em);
      $this->output->writeln('<comment>' . count($orders) . ' orders found</comment>');
      foreach ($orders as $o) {
        $this->output->writeln('<info>pending order: '.$o->getSms().'</info>');

        // queue managers alerts
        if ($o->getPendingTime() > OrderManager::MAX_PENDING_TIME_MANAGER / 60 && 
            !in_array($o->getId(), $this->manager_alerted_orders) &&
            !$o->getIsManagerAlerted()) {
          $manager_to_alert[$o->getRestaurant()->getId()][] = $o;
        }

        // update order
        if ($o->getPendingTime() > OrderManager::MAX_PENDING_TIME_ORDER/60) {
          $om = new OrderManager($o, $this->em, $this->getContainer()->get('session'));
          $om->answer('no_manager_response', null, $this->getContainer());
          $this->output->writeln('<error>cancelled : ' . $o->getSms() . '</error>');
        }
      }


      // alert manager
      $brickstormsms = $this->getContainer()->get('brickstorm.sms');
      foreach ($manager_to_alert as $r_id => $os) {
        $msg = $this->getContainer()->get('translator')->trans('sms.manager.alert.order', 
                                                               array('%count%' => count($os), 
                                                                     '%time%'  => $manager_delay.' minutes'));
        mail('bbergstorm@gmail.com', 'smsFood : cronCommand > checkOrders', $msg);
        $brickstormsms->send('SmsFood',
                              $msg,
                              array($this->getContainer()->get('translator')->trans('service.admin.phonenumber'), 
                                    $os[0]->getRestaurant()->getPhonenumber()));
        $this->output->writeln('<error>alert manager : ' . $msg . '. ' . $os[0]->getRestaurant()->getPhonenumber() . '</error>');
        foreach ($os as $o) {
          $this->manager_alerted_orders[] = $o->getId();
          $o->setIsManagerAlerted(1);
        }
        $this->em->flush();
      }

      //mail('bbergstorm@gmail.com', 'cronCommand > check o', count($orders).', to_alert:'. count($manager_to_alert));
    }

    /**
    * check pending bookings without answer
    *
    *
    */
    protected function checkBookings($pending_time)
    {
      $manager_delay    = (BookingManager::MAX_PENDING_TIME_ORDER - BookingManager::MAX_PENDING_TIME_MANAGER) / 60;
      $manager_to_alert = array();
      $bookings         = BookingManager::getPending($this->em);
      $this->output->writeln('<comment>' . count($bookings) . ' bookings found</comment>');
      foreach ($bookings as $b) {
        $this->output->writeln('<info>pending booking: '.$b->getSms().'</info>');

        // queue managers alerts
        if ($b->getPendingTime() > BookingManager::MAX_PENDING_TIME_MANAGER / 60 && 
            !in_array($b->getId(), $this->manager_alerted_bookings) &&
            !$b->getIsManagerAlerted()) {
          $manager_to_alert[$b->getRestaurant()->getId()][] = $b;
        }

        // update order
        if ($b->getPendingTime() > BookingManager::MAX_PENDING_TIME_ORDER/60) {
          $bm = new BookingManager($b, $this->em, $this->getContainer()->get('session'));
          $bm->answer('no_manager_response', null, $this->getContainer());
        }
      }

      // alert manager
      $brickstormsms = $this->getContainer()->get('brickstorm.sms');
      foreach ($manager_to_alert as $r_id => $bs) {
        $msg = $this->getContainer()->get('translator')->trans('sms.manager.alert.booking', 
                                                               array('%count%' => count($bs), 
                                                                     '%time%'  => $manager_delay.' minutes'));
        mail('bbergstorm@gmail.com', 'smsFood : cronCommand > checkBookings', $msg);
        $brickstormsms->send('SmsFood',
                              $msg,
                              array($this->getContainer()->get('translator')->trans('service.admin.phonenumber'), 
                                    $bs[0]->getRestaurant()->getPhonenumber()));
        foreach ($bs as $b) {
          $this->manager_alerted_bookings[] = $b->getId();
          $b->setIsManagerAlerted(1);
        }
        $this->em->flush();
      }
    }

    /*$name = $input->getArgument('name');
    if ($name) {
        $text = 'Hello '.$name;
    } else {
        $text = 'Hello';
    }

    if ($input->getOption('yell')) {
        $text = strtoupper($text);
    }

    $output->writeln($text);
    
    // -- color text
    // green text
    $output->writeln('<info>foo</info>');
    // yellow text
    $output->writeln('<comment>foo</comment>');
    // black text on a cyan background
    $output->writeln('<question>foo</question>');
    // white text on a red background
    $output->writeln('<error>foo</error>');

    //dialog
    $dialog = $this->getHelperSet()->get('dialog');
    if (!$dialog->askConfirmation($output, '<question>Continue with this action?</question>', false)) {
        return;
    }
    $dialog = $this->getHelperSet()->get('dialog');
    $name = $dialog->ask($output, 'Please enter the name of the widget', 'foo');
        

    // -- Testing Commands
    public function testExecute()
    {
        // mock the Kernel or create one depending on your needs
        $application = new Application($kernel);

        $command = $application->find('demo:greet');
        $commandTester = new CommandTester($command);
        $commandTester->execute(array('command' => $command->getFullName()));

        $this->assertRegExp('/.../', $commandTester->getDisplay());

        // ...
    }
    // -- Getting Services from the Service Container¶
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $name = $input->getArgument('name');
        $translator = $this->getContainer()->get('translator');
        if ($name) {
            $output->writeln($translator->trans('Hello %name%!', array('%name%' => $name)));
        } else {
            $output->writeln($translator->trans('Hello!'));
        }
    }
    // -- Calling an existing Command
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $command = $this->getApplication()->find('demo:greet');
    
        $arguments = array(
            'command' => 'demo:greet',
            'name'    => 'Fabien',
            '--yell'  => true,
        );
    
        $input = new ArrayInput($arguments);
        $returnCode = $command->run($input, $output);
    
        // ...
    }
    */
}