<?php

namespace Brickstorm\Sms4FoodBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Brickstorm\Sms4FoodBundle\Entity\Booking
 */
class Booking
{

  public function __toString()
  {
      return $this->id.'-'.$this->phonenumber;
  }

  public function getArrivalTime()
  {
    return $this->isAccepted() ? round(($this->time->format('U') - time()) / 60) : null;
  }

  public function isAccepted()
  {
    return $this->accepted_at && $this->accepted_at->format('U') > 0 ? true : false;
  }

  /**
    * Get sms without restaurant hashtag
    *
    * @return string 
    */
  public function getSmsShortened()
  {
      return str_replace('@'.$this->restaurant->getHashtag().' ', '', $this->sms);
  }

  public function getState()
  {
    if ($this->is_call_required) {
      return 'call-required';
    } elseif ($this->isAccepted()) {
      return 'accepted';
    } elseif ($this->is_rejected or $this->is_cancelled) {
      return 'cancelled';
    } else {
      return 'pending';
    }
  }

  //auto generated

    /**
     * @var integer $id
     */
    private $id;

    /**
     * @var string $phonenumber
     */
    private $phonenumber;

    /**
     * @var string $sms
     */
    private $sms;

    /**
     * @var time $time
     */
    private $time;

    /**
     * @var integer $nb_clients
     */
    private $nb_clients;

    /**
     * @var string $hashtag
     */
    private $hashtag;

    /**
     * @var boolean $is_rejected
     */
    private $is_rejected = 0;

    /**
     * @var boolean $is_call_required
     */
    private $is_call_required = 0;

    /**
     * @var boolean $is_cancelled
     */
    private $is_cancelled = 0;

    /**
     * @var boolean $is_manager_alerted
     */
    private $is_manager_alerted = 0;

    /**
     * @var datetime $accepted_at
     */
    private $accepted_at;

    /**
     * @var datetime $expected_at
     */
    private $expected_at;

    /**
     * @var datetime $created_at
     */
    private $created_at;

    /**
     * @var Application\Sonata\UserBundle\Entity\User
     */
    private $user;

    /**
     * @var Brickstorm\Sms4FoodBundle\Entity\Restaurant
     */
    private $restaurant;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set phonenumber
     *
     * @param string $phonenumber
     */
    public function setPhonenumber($phonenumber)
    {
        $this->phonenumber = $phonenumber;
    }

    /**
     * Get phonenumber
     *
     * @return string 
     */
    public function getPhonenumber()
    {
        return $this->phonenumber;
    }

    /**
     * Set sms
     *
     * @param string $sms
     */
    public function setSms($sms)
    {
        $this->sms = $sms;
    }

    /**
     * Get sms
     *
     * @return string 
     */
    public function getSms()
    {
        return $this->sms;
    }

    /**
     * Set time
     *
     * @param time $time
     */
    public function setTime($time)
    {
        $this->time = $time;
    }

    /**
     * Get time
     *
     * @return time 
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * Set nb_clients
     *
     * @param integer $nbClients
     */
    public function setNbClients($nbClients)
    {
        $this->nb_clients = $nbClients;
    }

    /**
     * Get nb_clients
     *
     * @return integer 
     */
    public function getNbClients()
    {
        return $this->nb_clients;
    }

    /**
     * Set hashtag
     *
     * @param string $hashtag
     */
    public function setHashtag($hashtag)
    {
        $this->hashtag = $hashtag;
    }

    /**
     * Get hashtag
     *
     * @return string 
     */
    public function getHashtag()
    {
        return $this->hashtag;
    }

    /**
     * Set is_rejected
     *
     * @param boolean $isRejected
     */
    public function setIsRejected($isRejected)
    {
        $this->is_rejected = $isRejected;
    }

    /**
     * Get is_rejected
     *
     * @return boolean 
     */
    public function getIsRejected()
    {
        return $this->is_rejected;
    }

    /**
     * Set is_call_required
     *
     * @param boolean $isCallRequired
     */
    public function setIsCallRequired($isCallRequired)
    {
        $this->is_call_required = $isCallRequired;
    }

    /**
     * Get is_call_required
     *
     * @return boolean 
     */
    public function getIsCallRequired()
    {
        return $this->is_call_required;
    }

    /**
     * Set expected_at
     *
     * @param datetime $expectedAt
     */
    public function setExpectedAt($expectedAt)
    {
        $this->expected_at = $expectedAt;
    }

    /**
     * Get expected_at
     *
     * @return datetime 
     */
    public function getExpectedAt()
    {
        return $this->expected_at;
    }

    /**
     * Set created_at
     *
     * @param datetime $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->created_at = $createdAt;
    }

    /**
     * Get created_at
     *
     * @return datetime 
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * Set user
     *
     * @param Application\Sonata\UserBundle\Entity\User $user
     */
    public function setUser(\Application\Sonata\UserBundle\Entity\User $user)
    {
        $this->user = $user;
    }

    /**
     * Get user
     *
     * @return Application\Sonata\UserBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set restaurant
     *
     * @param Brickstorm\Sms4FoodBundle\Entity\Restaurant $restaurant
     */
    public function setRestaurant(\Brickstorm\Sms4FoodBundle\Entity\Restaurant $restaurant)
    {
        $this->restaurant = $restaurant;
    }

    /**
     * Get restaurant
     *
     * @return Brickstorm\Sms4FoodBundle\Entity\Restaurant 
     */
    public function getRestaurant()
    {
        return $this->restaurant;
    }

    /**
     * Set is_cancelled
     *
     * @param boolean $isCancelled
     */
    public function setIsCancelled($isCancelled)
    {
        $this->is_cancelled = $isCancelled;
    }

    /**
     * Get is_cancelled
     *
     * @return boolean 
     */
    public function getIsCancelled()
    {
        return $this->is_cancelled;
    }

    /**
     * Set accepted_at
     *
     * @param datetime $acceptedAt
     */
    public function setAcceptedAt($acceptedAt)
    {
        $this->accepted_at = $acceptedAt;
    }

    /**
     * Get accepted_at
     *
     * @return datetime 
     */
    public function getAcceptedAt()
    {
        return $this->accepted_at;
    }

    /**
     * Set is_manager_alerted
     *
     * @param boolean $isManagerAlerted
     */
    public function setIsManagerAlerted($isManagerAlerted)
    {
        $this->is_manager_alerted = $isManagerAlerted;
    }

    /**
     * Get is_manager_alerted
     *
     * @return boolean 
     */
    public function getIsManagerAlerted()
    {
        return $this->is_manager_alerted;
    }
}