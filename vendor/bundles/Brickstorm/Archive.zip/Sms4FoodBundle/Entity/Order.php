<?php

namespace Brickstorm\Sms4FoodBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Brickstorm\Sms4FoodBundle\Entity\Order
 */
class Order
{

  public function __toString()
  {
      return $this->id.'-'.$this->phonenumber;
  }

  public function getPendingTime()
  {
    return !$this->isCompleted() && !$this->getIsRejected() && !$this->getIsCancelled() ? (time() - $this->created_at->format('U')) / 60 : null;
  }

  public function getRemainingTime()
  {
    return !$this->isCompleted() && !$this->getIsRejected() && !$this->getIsCancelled() && $this->expected_at ? round(($this->expected_at->format('U') - time()) / 60) : null;
  }

  public function isCompleted()
  {
    return $this->completed_at && $this->completed_at->format('U') > 0 ? true : false;
  }

  public function isExpected()
  {
    return $this->expected_at && $this->expected_at->format('U') > time() ? true : false;
  }

  public function getState()
  {
    if ($this->is_call_required) {
      return 'call-required';
    } elseif ($this->isCompleted()) {
      return 'completed';
    } elseif ($this->is_rejected || $this->is_cancelled) {
      return 'cancelled';
    } else {
      return 'pending';
    }
  }

  /**
    * add to sms string
    */
  public function addToSms($sms)
  {
      $this->sms .= ' ' . $sms;
  }

  /**
    * Get sms without restaurant hashtag
    *
    * @return string 
    */
  public function getSmsShortened()
  {
      return str_replace('@'.$this->restaurant->getHashtag().' ', '', $this->sms);
  }

  /**
    * Get sms without restaurant hashtag
    *
    * @return string 
    */
  public function getSmsComment()
  {
     $sms = $this->getSmsShortened();
     foreach ($this->getOrderfoods() as $of) {
      //echo 'HERE'.$of->getQuantity().'#'.$of->getFood()->getHashtag();
       $sms = str_ireplace($of->getQuantity().'#'.$of->getFood()->getHashtag(), '', $sms);
     }
     
     return $sms;
  }

  //auto generated

    /**
     * @var integer $id
     */
    private $id;

    /**
     * @var integer $phonenumber
     */
    private $phonenumber;

    /**
     * @var string $sms
     */
    private $sms;

    /**
     * @var Brickstorm\Sms4FoodBundle\Entity\Restaurant
     */
    private $restaurant;

    /**
     * @var Brickstorm\Sms4FoodBundle\Entity\OrderFood
     */
    private $orderfoods;

    /**
     * @var boolean $is_call_required
     */
    private $is_call_required = 0;

    /**
     * @var boolean $is_rejected
     */
    private $is_rejected = 0;

    /**
     * @var boolean $is_cancelled
     */
    private $is_cancelled = 0;

    /**
     * @var boolean $is_manager_alerted
     */
    private $is_manager_alerted = 0;

    /**
     * @var datetime $expected_at
     */
    private $expected_at;

    /**
     * @var datetime $completed_at
     */
    private $completed_at;

    /**
     * @var string $hashtag
     */
    private $hashtag;

    /**
     * @var Application\Sonata\UserBundle\Entity\User
     */
    private $user;

    /**
     * @var date $created_at
     */
    private $created_at;



    public function __construct()
    {
        $this->orderfoods = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set phonenumber
     *
     * @param integer $phonenumber
     */
    public function setPhonenumber($phonenumber)
    {
        $this->phonenumber = $phonenumber;
    }

    /**
     * Get phonenumber
     *
     * @return integer 
     */
    public function getPhonenumber()
    {
        return $this->phonenumber;
    }

    /**
     * Set sms
     *
     * @param string $sms
     */
    public function setSms($sms)
    {
        $this->sms = $sms;
    }

    /**
     * Get sms
     *
     * @return string 
     */
    public function getSms()
    {
        return $this->sms;
    }

    /**
     * Set created_at
     *
     * @param date $createdAt
     */
    public function setCreatedAt($createdAt)
    {
        $this->created_at = $createdAt;
    }

    /**
     * Get created_at
     *
     * @return date 
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * Set restaurant
     *
     * @param Brickstorm\Sms4FoodBundle\Entity\Restaurant $restaurant
     */
    public function setRestaurant(\Brickstorm\Sms4FoodBundle\Entity\Restaurant $restaurant)
    {
        $this->restaurant = $restaurant;
    }

    /**
     * Get restaurant
     *
     * @return Brickstorm\Sms4FoodBundle\Entity\Restaurant 
     */
    public function getRestaurant()
    {
        return $this->restaurant;
    }

    /**
     * Add foods
     *
     * @param Brickstorm\Sms4FoodBundle\Entity\OrderFood $foods
     */
    public function addOrderFood(\Brickstorm\Sms4FoodBundle\Entity\OrderFood $of)
    {
        $this->orderfoods[] = $of;
    }

    /**
     * Get orderfoods
     *
     * @return Doctrine\Common\Collections\Collection 
     */
    public function getOrderfoods()
    {
        return $this->orderfoods;
    }

    /**
     * Set is_call_required
     *
     * @param boolean $isCallRequired
     */
    public function setIsCallRequired($isCallRequired)
    {
        $this->is_call_required = $isCallRequired;
    }

    /**
     * Get is_call_required
     *
     * @return boolean 
     */
    public function getIsCallRequired()
    {
        return $this->is_call_required;
    }

    /**
     * Set expected_at
     *
     * @param datetime $expectedAt
     */
    public function setExpectedAt($expectedAt)
    {
        $this->expected_at = $expectedAt;
    }

    /**
     * Get expected_at
     *
     * @return datetime 
     */
    public function getExpectedAt()
    {
        return $this->expected_at;
    }

    /**
     * Set is_rejected
     *
     * @param boolean $isRejected
     */
    public function setIsRejected($isRejected)
    {
        $this->is_rejected = $isRejected;
    }

    /**
     * Get is_rejected
     *
     * @return boolean 
     */
    public function getIsRejected()
    {
        return $this->is_rejected;
    }

    /**
     * Set hashtag
     *
     * @param string $hashtag
     */
    public function setHashtag($hashtag)
    {
        $this->hashtag = $hashtag;
    }

    /**
     * Get hashtag
     *
     * @return string 
     */
    public function getHashtag()
    {
        return $this->hashtag;
    }

    /**
     * Set user
     *
     * @param Application\Sonata\UserBundle\Entity\User $user
     */
    public function setUser(\Application\Sonata\UserBundle\Entity\User $user)
    {
        $this->user = $user;
    }

    /**
     * Get user
     *
     * @return Application\Sonata\UserBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set is_cancelled
     *
     * @param boolean $isCancelled
     */
    public function setIsCancelled($isCancelled)
    {
        $this->is_cancelled = $isCancelled;
    }

    /**
     * Get is_cancelled
     *
     * @return boolean 
     */
    public function getIsCancelled()
    {
        return $this->is_cancelled;
    }

    /**
     * Set completed_at
     *
     * @param datetime $completedAt
     */
    public function setCompletedAt($completedAt)
    {
        $this->completed_at = $completedAt;
    }

    /**
     * Get completed_at
     *
     * @return datetime 
     */
    public function getCompletedAt()
    {
        return $this->completed_at;
    }

    /**
     * Set is_manager_alerted
     *
     * @param boolean $isManagerAlerted
     */
    public function setIsManagerAlerted($isManagerAlerted)
    {
        $this->is_manager_alerted = $isManagerAlerted;
    }

    /**
     * Get is_manager_alerted
     *
     * @return boolean 
     */
    public function getIsManagerAlerted()
    {
        return $this->is_manager_alerted;
    }
    /**
     * @var Brickstorm\WorldBundle\Entity\Location
     */
    private $location;


    /**
     * Set location
     *
     * @param Brickstorm\WorldBundle\Entity\Location $location
     */
    public function setLocation(\Brickstorm\WorldBundle\Entity\Location $location)
    {
        $this->location = $location;
    }

    /**
     * Get location
     *
     * @return Brickstorm\WorldBundle\Entity\Location 
     */
    public function getLocation()
    {
        return $this->location;
    }
}