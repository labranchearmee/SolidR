<?php
namespace Brickstorm\Sms4FoodBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilder;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\MinLength;
use Symfony\Component\Validator\Constraints\Collection;

class SmsType extends AbstractType
{
    /**
    *
    *
    */
    public function buildForm(FormBuilder $builder, array $options)
    {
      $builder->add('phonenumber', 
                    'number', 
                    array('required' => true, 
                          'attr' => array('placeholder' => $this->get('translator')->trans('form.placeholder.phonenumber')),
                                          'max_length'  => 11));
      $builder->add('restaurant', 
                    'choice', 
                    array('choices'   => $choices, 
                          'required'  => true));
      $builder->add('sms', 
                    'textarea', 
                    array('required'  => true,
                          'attr' => array('placeholder' => $this->get('translator')->trans('form.placeholder.sms.home'))));
    }

    /**
    *
    *
    */
    public function getName()
    {
        return 'sms';
    }

    /**
    *
    *
    */
    public function getDefaultOptions(array $options)
    {
        $collectionConstraint = new Collection(array(
            'phonenumber'  => new MinLength(11),
            'sms'          => new MinLength(5),
        ));

        return array('validation_constraint' => $collectionConstraint,
                     'csrf_protection'       => true,
                     'csrf_field_name'       => '_token');
    }
}