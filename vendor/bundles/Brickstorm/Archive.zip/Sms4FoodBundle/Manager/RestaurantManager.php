<?php

namespace Brickstorm\Sms4FoodBundle\Manager;

use Application\Sonata\UserBundle\Entity\User;

use Brickstorm\Sms4FoodBundle\Entity\Order;
use Brickstorm\Sms4FoodBundle\Entity\Booking;
use Brickstorm\Sms4FoodBundle\Entity\Restaurant;

use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Query\ResultSetMapping;

class RestaurantManager
{
    protected $em         = null;
    protected $restaurant = null;

    public function __construct(Restaurant &$restaurant, EntityManager $em){
      $this->em         = $em;
      $this->restaurant = $restaurant;
    }

    /**
    *
    */
    public function getFoodtypes() {
      $qb = $this->em->createQueryBuilder();
      $qb->add('select', 'ft')
         ->add('from', 'Brickstorm\Sms4FoodBundle\Entity\FoodType ft')
         ->innerJoin('ft.foods', 'f')
         ->innerJoin('f.restaurant', 'r')
         ->GroupBy('ft.id');
      $query = $qb->getQuery();

      return $query->getResult();
    }


    /**
    *
    */
    public function cleanSms($sms){
      $from = array(' :', ': ', ' : ', '@ ');
      $to   = array(':', ':', ':', '@');

      return str_replace($from, $to, $sms);
    }

    /**
    *
    */
    public function fromSms($sms){
      $sms = self::cleanSms($sms);

      foreach (explode(' ', $sms) as $item) {
        if (preg_match('/@(?<hashtag>\w+)/', $item, $matches)) {
          $r = $this->em->getRepository('BrickstormSms4FoodBundle:Restaurant')
                        ->findOneByHashtag($matches['hashtag']);
          if (is_object($r)) {
            $this->restaurant = $r;
            return $r;
          }
        }
      }
    }

    /**
    *
    */
    public function toSms(){
      return '@'.$this->restaurant->getHashtag();
    }

    /**
    * get ending orders
    */
    public static function getOrdersByRestaurant(\Application\Sonata\UserBundle\Entity\User $user, EntityManager $em){
      $qb = $em->createQueryBuilder();
      $qb->add('select', 'o')
         ->add('from', 'BrickstormSms4FoodBundle:Order o')
         ->innerJoin('o.restaurant', 'r', 'WITH',  $qb->expr()->eq('r.user', '?1'))
         ->add('where', $qb->expr()->orx(
                              'o.created_at IS NULL',
                              $qb->expr()->gt('o.created_at', '?2')
                           )
                 )
         ->setParameter(1, $user)
         ->setParameter(2, date('Y-m-d H:i:s', time()- 72 * 3600))
         ->orderBy('o.created_at', 'DESC');
      $query = $qb->getQuery();
      //echo $qb->getDql();
      $orders = array();
      foreach ($query->getResult() as $o) {
        $orders[$o->getRestaurant()->getId()][] = $o;
      }

      return $orders;
    }

    /**
    * get pending bookings
    */
    public static function getBookingsByRestaurant(\Application\Sonata\UserBundle\Entity\User $user, EntityManager $em){
      $qb = $em->createQueryBuilder();
      $qb->add('select', 'b')
         ->add('from', 'BrickstormSms4FoodBundle:Booking b')
         ->innerJoin('b.restaurant', 'r', 'WITH',  $qb->expr()->eq('r.user', '?1'))
         ->add('where', $qb->expr()->orx(
                              'b.created_at IS NULL',
                              $qb->expr()->gt('b.created_at', '?2')
                           )
                 )
         ->setParameter(1, $user)
         ->setParameter(2, date('Y-m-d H:i:s', time()-7200))
         ->orderBy('b.created_at', 'DESC');
      $query = $qb->getQuery();

      $bookings = array();
      foreach ($query->getResult() as $b) {
        $bookings[$b->getRestaurant()->getId()][] = $b;
      }

      return $bookings;
    }

    /**
    * report orders by month
    */
    public function getOrdersByMonth($year=null){
      $year = $year == null ? date('Y') : $year;

      $rsm = new ResultSetMapping;
      
      $rsm->addScalarResult('nb', 'nb');
      $rsm->addScalarResult('month', 'month');
      
      $query = $this->em->createNativeQuery('SELECT count(o.id) as nb, MONTH(o.created_at) as month '.
                                            'FROM b_sms4food__order o '.
                                            'WHERE o.restaurant_id = ? '.
                                            'AND YEAR(o.created_at) = ? '.
                                            'GROUP BY MONTH(o.created_at)', $rsm)
                         ->setParameter(1, $this->restaurant->getId())
                         ->setParameter(2, (int)$year)
                         ;

      $report = array();
      foreach ($query->getScalarResult() as $r) {
        $report[$r['month']] = $r['nb'];
      }

      return $report;
    }

    /**
    * report bookings by month
    */
    public function getBookingsByMonth($year=null){
      $year = $year == null ? date('Y') : $year;

      $rsm = new ResultSetMapping;
      
      $rsm->addScalarResult('nb', 'nb');
      $rsm->addScalarResult('month', 'month');
      
      $query = $this->em->createNativeQuery('SELECT count(id) as nb, MONTH(b.created_at) as month '.
                                            'FROM b_sms4food__booking b '.
                                            'WHERE b.restaurant_id = ? '.
                                            'AND YEAR(b.created_at) = ? '.
                                            'GROUP BY b.id', $rsm)
                         ->setParameter(1, $this->restaurant->getId())
                         ->setParameter(2, (int)$year)
                         ;

      $report = array();
      foreach ($query->getScalarResult() as $r) {
        $report[$r['month']] = $r['nb'];
      }

      return $report;
    }

    /**
    * report delivery by month
    */ 
    public function getDeliveriesByMonth($year=null){
      $year = $year == null ? date('Y') : $year;
      $rsm = new ResultSetMapping;
      
      $rsm->addScalarResult('nb', 'nb');
      $rsm->addScalarResult('month', 'month');
      
      $query = $this->em->createNativeQuery('SELECT count(1) as nb, '.
                                            '(CASE WHEN o.phonenumber THEN o.phonenumber ELSE b.phonenumber END) as phonenumber, '.
                                            'MONTH(CASE WHEN o.created_at THEN o.created_at ELSE b.created_at END) as month '.
                                            'FROM b_sms4food__restaurant r '.
                                            'LEFT JOIN b_sms4food__order o ON r.id = o.restaurant_id '.
                                            'LEFT JOIN b_sms4food__booking b ON r.id = b.restaurant_id '.
                                            'WHERE r.id = ? '.
                                            'AND YEAR(CASE WHEN o.created_at THEN o.created_at ELSE b.created_at END) = ? '.
                                            'GROUP BY phonenumber', $rsm)
                         ->setParameter(1, $this->restaurant->getId())
                         ->setParameter(2, (int)$year)
                         ;


      $report = array();
      foreach ($query->getScalarResult() as $r) {
        $report[$r['month']] = $r['nb'];
      }

      return $report;
    }

    /**
    * report new user by month
    */
    public function getNewUsersByMonth($year=null){
      $year = $year == null ? date('Y') : $year;
      $rsm = new ResultSetMapping;
      
      $rsm->addScalarResult('nb', 'nb');
      $rsm->addScalarResult('month', 'month');
      
      $query = $this->em->createNativeQuery('SELECT count(o.id) as nb, MONTH(o.created_at) as month '.
                                            'FROM b_sms4food__order o '.
                                            'JOIN b_sms4food__location l ON l.id = o.location_id '.
                                            'WHERE o.restaurant_id = ? '.
                                            'AND YEAR(o.created_at) = ? '.
                                            'GROUP BY o.id', $rsm)
                         ->setParameter(1, $this->restaurant->getId())
                         ->setParameter(2, (int)$year)
                         ;


      $report = array();
      foreach ($query->getScalarResult() as $r) {
        $report[$r['month']] = $r['nb'];
      }

      return $report;
    }
}