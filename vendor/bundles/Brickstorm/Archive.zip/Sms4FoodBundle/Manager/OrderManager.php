<?php

namespace Brickstorm\Sms4FoodBundle\Manager;

use Application\Sonata\UserBundle\Entity\User;

use Brickstorm\Sms4FoodBundle\Entity\Order;
use Brickstorm\Sms4FoodBundle\Entity\Restaurant;
use Brickstorm\Sms4FoodBundle\Entity\OrderFood;

use Doctrine\ORM\EntityManager;

class OrderManager
{
    CONST MAX_PENDING_TIME_MANAGER = 300; //5 minutes
    CONST MAX_PENDING_TIME_ORDER   = 900; //15 minutes

    protected $em         = null;
    protected $order      = null;
    protected $restaurant = null;

    public function __construct(Order &$order, EntityManager $em, $session = null){
      $this->em         = $em;
      $this->session    = $session;
      $this->order      = $order;
      $this->restaurant = $order->getRestaurant();
    }

    public static function reset($session) {
      $session->set('current_order', null);
    }

    /**
    * check if the sms is an order
    */
    public static function matchSMS($sms) {
      if (preg_match('/@(?<hashtag_restaurant>\w+)/', $sms, $matches) //&&
          //preg_match('/(?<count>\d+|)(#|:|.)(?<hashtag_food>\w+)+/', $sms, $matches)
          ) {

        return true;
      }
    }

    /**
    * validate that the order food list is not empty
    */
    public function validate() {
      
      /** in database
      if (count($this->order->getOrderFoods()) == 0 && 
          count($this->session->get('current_order')) == 0) {
        return false;
      }*/

      return true;
    }

    /**
    *
    */
    public function updateOrderFood($f, $quantity, $add=false) {
      $of = $this->em->getRepository('BrickstormSms4FoodBundle:OrderFood')
                     ->findBy(array('order' => $this->order, 
                                    'food'  => $f));
      if (!is_object($of) && $quantity > 0) {
        $of = new OrderFood();
        $of->setFood($f);
        $of->setOrder($this->order);
        $of->setQuantity($quantity);
      }

      if (is_object($of)) {
        if ($add) {
          $of->addToQuantity($quantity);
        }
        if ($of->getQuantity() < 1) {
          //$this->em->remove($of);
          //$this->em->flush();
        } else {
          //$this->em->persist($of);
          //$this->em->flush();
        }
      
        $this->order->addOrderFood($of);
      }
    }

    /**
    *
    */
    public function calculateOrderFood($f, $quantity, $add=false) {

      $current = $this->session->get('current_order');

      if (!isset($current[$f->getHashtag()])) {
        if ($quantity > 0) {
          $current[$f->getHashtag()] = $quantity;
        }
      } else {
        $quantity = $current[$f->getHashtag()] + ($add ? $quantity : 0);
        if ($quantity > 0) {
          $current[$f->getHashtag()] = $quantity;
        } elseif ($quantity == 0) {
          unset($current[$f->getHashtag()]);
        }
      }

      $this->session->set('current_order', $current);
    }

    /**
    *
    */
    public function cleanSms($sms){
      $from = array(' :', ': ', ' : ', ' .', '. ', ' . ', '@ ');
      $to   = array(':', ':', ':', '.', '.', '.', '@');

      return str_replace($from, $to, $sms);
    }

    /**
    *
    */
    public function fromSms($sms=null, $add=false, $update_orderfoods=true){
      if ($sms) {
        $this->sms = self::cleanSms($sms);
        $this->order->setSms($sms);
      }
      $this->sms = $this->order->getSms() ? $this->order->getSms() : str_replace('@'.$this->restaurant->getHashtag(), '', urldecode($sms));
      //echo "\n".'OrderManager::fromSms > $this->sms:'.$this->sms;
      foreach (explode(' ', $this->sms) as $item) {
        //to products
        if (preg_match('/(?<operator>(-|))(?<count>(\d+|))(#|x|:|.)(?<hashtag>\w+)+/', $item, $matches)) {
          $f = $this->em->getRepository('BrickstormSms4FoodBundle:Food')
                        ->findOneByHashtag($matches['hashtag']);
          if (is_object($f)) {
            //echo "\n".'preg_match:products => '.$matches['hashtag'];
            $matches['count'] = $matches['count'] > 0 ? $matches['count'] : 1;
            $quantity = $matches['operator'] == '-' ? -$matches['count'] : $matches['count'];
            //echo 'update_orderfoods:'.$update_orderfoods;
            if ($update_orderfoods) {
              $this->updateOrderFood($f, $quantity, $add);
            }
            $this->calculateOrderFood($f, $quantity, $add);
          }

        //add save order or location
        } elseif (preg_match('/^(#|:|.)(?<hashtag>\w+)$/', $item, $matches)) {
          //echo 'preg_match:location/order hashtag:'.$matches['hashtag'].', user:'.$this->order->getUser();
          //delivery location ?
          $l = $this->em->getRepository('BrickstormSms4FoodBundle:Location')
                        ->findOneBy(array('user'    => $this->order->getUser(),
                                          'hashtag' => $matches['hashtag']));
          if (is_object($l)) {
            //echo 'preg_match:location';
            $this->order->setLocation($l);

          //order ?
          } else {
            $o = $this->em->getRepository('BrickstormSms4FoodBundle:Order')
                        ->findOneBy(array('user'    => $this->order->getUser(),
                                          'hashtag' => $matches['hashtag']));
            if (is_object($o) && 
                $o->getRestaurant()->getId() == $this->restaurant->getId()) {
              $this->fromSms($o->getSmsShortened());
              $this->order->addToSms($o->getSmsShortened());
            }
          }
        }
      }
    }

    /**
    *
    */
    public function toSms($hashtag_mode=false){
      //echo 'toSms hashtag_mode:'.$hashtag_mode.' location:'.$this->order->getLocation();
      $this->sms = '@'.$this->restaurant->getHashtag();

      //hashtag 
      if ($hashtag_mode) {
        $this->sms .= ' #'.$this->order->getHashtag();

      } else {

        $current = $this->session->get('current_order');

        //from products
        //if ($this->order->getId()) {
        //  foreach ($this->order->getOrderFoods() as $of) {
        //    $this->sms .= ' '.$of->getQuantity().'#'.$of->getFood()->getHashtag();
        //  }
        //} else
        if (is_array($current)) {
          foreach ($current as $hashtag => $count) {
            $this->sms .= ' '.$count.'#'.$hashtag;
          }
        }

        //delivery
        if ($l = $this->order->getLocation()) {
          $this->sms .= ' #'.$l->getHashtag();
        }
      }

      return $this->sms;
    }

    /**
    * first order for the user ?
    */
    public function isFirstOne(){
      if ($this->order->getUser() && 
          count($this->order->getUser()->getOrders()) == 1) {
        return true;
      }
    }

    /**
    *
    */
    public function answer($type, $delay=null, $container) {

      $params = array('%sms%'         => $this->order->getSmsShortened(),
                      '%restaurant%'  => $this->order->getRestaurant()->getName(),
                      '%phonenumber%' => $this->order->getRestaurant()->getPhonenumber(),
                      '%type%'        => $container->get('translator')->trans($this->order->getLocation() ? 'order.delivery' : 'order.order'));

      switch ($type) {
          case 'accept':
            $params['%delay%'] = $delay;
            $this->order->setCompletedAt(date_create('now'));
            $this->order->setExpectedAt(date_create('@'.(time() + $params['%delay%']*60)));
            $this->order->setIsCallRequired(false);
            $this->order->setIsRejected(false);
          break;
          case 'cancel':
          case 'no_manager_response':
            $this->order->setIsCancelled(true);
            $this->order->setIsCallRequired(false);
            $this->order->setCompletedAt(null);
          break;
          case 'reject':
            $this->order->setIsRejected(true);
            $this->order->setIsCallRequired(false);
          break;
          case 'require-call':
            $this->order->setIsCallRequired(true);
            $this->order->setIsRejected(false);
          break;
        }

        $this->em->persist($this->order);
        $this->em->flush();

        //send SMS reply
        if ($sms = $container->get('translator')->trans('sms.order.answer.'.$type, $params)) {

          $brickstormsms = $container->get('brickstorm.sms');
          $brickstormsms->send($container->get('translator')->trans('service.from'),
                               $sms,
                               $this->order->getPhonenumber());
        }
    }

    /**
    * get pendings orders
    */
    public static function getPending(EntityManager $em){
      $qb = $em->createQueryBuilder();
      $qb->add('select', 'o')
         ->add('from', 'BrickstormSms4FoodBundle:Order o')
         ->add('where', $qb->expr()->andx('o.created_at < ?1', 'o.completed_at IS NULL', 'o.is_call_required = 0', 'o.is_cancelled = 0', 'o.is_rejected = 0'))
         ->add('orderBy', 'o.created_at ASC')
         ->setParameter(1, date('Y-m-d H:i:s', time() - self::MAX_PENDING_TIME_MANAGER));
      $q = $qb->getQuery();

      //mail('bbergstorm@gmail.com', 'smsFood : cronCommand > OrderManager::getPending', date('Y-m-d H:i:s', time() - self::MAX_PENDING_TIME_MANAGER), $qb->getDql());
      return $q->getResult();
    }
}