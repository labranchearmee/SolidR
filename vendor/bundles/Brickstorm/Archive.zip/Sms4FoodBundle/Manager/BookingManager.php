<?php

namespace Brickstorm\Sms4FoodBundle\Manager;

use Application\Sonata\UserBundle\Entity\User;

use Brickstorm\Sms4FoodBundle\Entity\Booking;
use Brickstorm\Sms4FoodBundle\Entity\Restaurant;
use Doctrine\ORM\EntityManager;

class BookingManager
{
    CONST MAX_PENDING_TIME_MANAGER = 300; //5 minutes
    CONST MAX_PENDING_TIME_ORDER   = 900; //15 minutes

    protected $em         = null;
    protected $booking      = null;
    protected $restaurant = null;

    public function __construct(Booking &$booking, EntityManager $em, $session = null){
      $this->em         = $em;
      $this->session    = $session;
      $this->booking    = $booking;
      $this->restaurant = $booking->getRestaurant();
    }

    public static function reset($session) {
      $session->set('current_booking', null);
    }

    /**
    * check if the sms is a booking
    */
    public static function matchSMS($sms) {
      
      if (preg_match('/@(?<hashtag_restaurant>\w+)/', $sms, $matches) &&
          preg_match('/ (?<count>\d+) /', $sms, $matches) &&
          preg_match('/(?<hour>\d+)(:|h)(?<mn>\d+|)/', $sms, $matches)) {

        return true;
      }
    }

    /**
    * validate that the order food list is not empty
    */
    public function validate() {

      return true;
    }

    /**
    *
    */
    public function updateBooking($param, $value) {
      
      // session
      $current = $this->session->get('current_booking');
      $current[$param] = $value;
      $this->session->set('current_booking', $current);

      //object
      switch ($param) {
        case 'person':
          $this->booking->setNbClients($value);
        break;
        case 'time':
          $this->booking->setTime(new \DateTime($value));
        break;
      }
      
      if ($this->booking->getId()) {
        $this->em->persist($this->booking);
        $this->em->flush();
      }
    }

    /**
    *
    */
    public function cleanSms($sms){
      $from = array(' :', ': ', ' : ', ' .', '. ', ' . ', '@ ');
      $to   = array(':', ':', ':', '.', '.', '.', '@');

      return str_replace($from, $to, $sms);
    }

    /**
    *
    */
    public function fromSms($sms=null){

      if ($sms) {
        $this->sms = self::cleanSms($sms);
        $this->booking->setSms($sms);
      }
 
      $this->sms = str_replace('@'.$this->restaurant->getHashtag(), '', urldecode($sms));

      foreach (explode(' ', $this->sms) as $item) {

        //count
        if (is_numeric($item)) {
          $this->updateBooking('person', $item);
        }
        //time
        if (preg_match('/(?<hour>\d+)(:|h)(?<mn>\d+|)/', $item, $matches)) {
          $dt = date('Y-m-d').' '.$matches['hour'].':'.($matches['mn'] ? $matches['mn'] : '00').':00';
          $this->updateBooking('time', $dt);
        }
      }
    }

    /**
    *
    */
    public function toSms(){
      $this->sms = '@'.$this->restaurant->getHashtag();

      $current = $this->session->get('current_booking');

      //from prodcts
      if ($this->booking->getId()) {
        if ($this->booking->getNbClients()) {
          $this->sms .= ' '.$this->booking->getNbClients();
        }
        if ($this->booking->getTime()) {
          $this->sms .= ' '.$this->booking->getTime().':'.$this->booking->getTime();
        }
      } elseif (is_array($current)) {
        foreach ($current as $hashtag => $count) {
          $this->sms .= ' '.$count;
        }
      }
      return $this->sms;
    }


    /**
    *
    */
    public function answer($type, $container) {

      $params = array('%sms%'         => $this->booking->getSmsShortened(),
                      '%restaurant%'  => $this->booking->getRestaurant()->getName(),
                      '%phonenumber%' => $this->booking->getRestaurant()->getPhonenumber());

      switch ($type) {
          case 'accept':
            $this->booking->setAcceptedAt(date_create('now'));
            $this->booking->setIsCallRequired(false);
            $this->booking->setIsRejected(false);
          break;
          case 'cancel':
          case 'no_manager_response':
            $this->booking->setIsCancelled(true);
            $this->booking->setIsCallRequired(false);
            $this->booking->setCompletedAt(null);
          break;
          case 'reject':
            $this->booking->setIsRejected(true);
            $this->booking->setIsCallRequired(false);
          break;
          case 'require-call':
            $this->booking->setIsCallRequired(true);
            $this->booking->setIsRejected(false);
          break;
        }

        $this->em->persist($this->booking);
        $this->em->flush();

        //send SMS reply
        if ($sms = $container->get('translator')->trans('sms.booking.answer.'.$type, $params)) {

          $brickstormsms = $container->get('brickstorm.sms');
          $brickstormsms->send($container->get('translator')->trans('service.from'),
                               $sms,
                               $this->booking->getPhonenumber());
        }
    }

    /**
    * first order for the user ?
    */
    public function isFirstOne(){
      if ($this->booking->getUser() && 
          count($this->booking->getUser()->getBookings()) == 1) {
        return true;
      }
    }

    /**
    * get pendings bookings
    */
    public static function getPending(EntityManager $em){
      $qb = $em->createQueryBuilder();
      $qb->add('select', 'b')
         ->add('from', 'BrickstormSms4FoodBundle:Booking b')
         ->add('where', $qb->expr()->andx('b.created_at < ?1', 'b.accepted_at IS NULL', 'b.is_call_required = 0', 'b.is_cancelled = 0', 'b.is_rejected = 0'))
         ->add('orderBy', 'b.created_at ASC')
         ->setParameter(1, date('Y-m-d H:i:s', time() - self::MAX_PENDING_TIME_MANAGER));
      $q = $qb->getQuery();
      
      return $q->getResult();
    }
}