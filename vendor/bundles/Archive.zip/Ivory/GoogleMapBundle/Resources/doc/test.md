# Test

The IvoryGoogleMapBundle is unit tested by PHPUnit.

For testing the bundle, you just have to execute the test suite

``` bash
$ phpunit
```

Previous : [Usage](http://github.com/egeloen/IvoryGoogleMapBundle/blob/master/Resources/doc/usage.md)