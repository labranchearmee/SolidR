# Google Map Layers

   - [KML Layer](http://github.com/egeloen/IvoryGoogleMapBundle/blob/master/Resources/doc/usage/layers/kml_layer.md)
   - Fusion Table Layer
   - Traffic Layer
   - Bicycling Layer
   - Panorama Layer
