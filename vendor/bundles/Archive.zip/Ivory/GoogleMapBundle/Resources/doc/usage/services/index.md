# Google Map API Services

   - Directions API
   - Distance Matrix API
   - Elevation API
   - [Geocoding API](http://github.com/egeloen/IvoryGoogleMapBundle/blob/master/Resources/doc/usage/services/geocoding/geocoder.md)
   - Places API
