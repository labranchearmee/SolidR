<?php

namespace Ivory\GoogleMapBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Google map bundle
 *
 * @author GeLo <geloen.eric@gmail.com>
 */
class IvoryGoogleMapBundle extends Bundle
{
    
}
