<?php

namespace Ivory\GoogleMapBundle\Model\Overlays;

/**
 * Each class implements this interface can be extend by a bound
 *
 * @author GeLo <geloen.eric@gmail.com>
 */
interface IExtendable
{

}
